################################################################################
# Robust Gaussian mixture fitting the EM with SPL
#
#  LAYOUT
#    1. Numerical helpers        (incl. the eigenvalue-ratio constraint)
#    2. Data generation (rGMM)
#    3. Main routine (gmm_em_spl)
#    4. Plotting
#    5. Evaluation
#    6. CONFIGURATION            <- the only place you edit design constants
#    7. Study helpers            (initialise / simulate / fit / score / save)
#    8. Export                   (per-replicate files, stacked sheet, or both)
#    9. Demonstration            (one dataset)
#   10. Monte Carlo run          (R replicates at CFG$alpha)
#   11. Contamination sweep      (all replicates at several alpha levels)
#   12. TWO-METHOD COMPARISON    (classical EM via mclust vs SPL-EM)
#   13. DIAGNOSTICS              (does the fit actually find the clusters?)
#   14. MEAN-ESTIMATE STORE      -> BIAS and MSE per scenario
#   15. EXECUTION               
#
# Section 1-5 are the machinery and never mention a design constant
# Section 6-14 are the study and read everything from cfg object.
# 
# Design:
#
#    Generating:  CFG$pie / CFG$mu / CFG$Sigma are the TRUE parameters. They
#                 draw the data and, at the end, serve as the target the
#                 estimates are scored against. No estimator sees them.
#    Fitting:     one trimmed-kmeans start per replicate, computed from that
#                 replicate's own X and shared by mclust EM and SPL-EM, so
#                 any difference in the estimates is attributable to the
#                 trimming and not to the start point.
#
# Requirements (packages to install)
#    mclust   which is classical for EM
#    openxlsx or writexl for the excel output


################################################################################
#   1. Numerical helpers 
################################################################################
#
# Log density of a multivariate normal evaluate at every row of X
# Uses the Cholesky factor:  Sigma = t(R) %*$ R
log_dmvn <- function(X, mu, Sigma) {
  X <- as.matrix(X)                                                             #force X to matrix form
  d <- ncol(X)                                                                  #getting number of columns
  R <- tryCatch(chol(Sigma), error = function(e) chol(Sigma + diag(1e-6, d)))   #Cholesky factor
  Xc <- sweep(X, 2, as.numeric(mu), "-")                                        #Centers the rows
  z  <- backsolve(R, t(Xc), transpose = TRUE)                                   # solve t(R) %*% z = t(Xc); z is d x n, the "whitened" residuals
  quad   <- colSums(z * z)                                                      #squared Mahalanobis distance per observation
  logdet <- 2 * sum(log(diag(R)))                                               # log|Sigma| = 2 * sum(log(diagonal of R));
  -0.5 * (d * log(2 * pi) + logdet + quad)                                      # the MVN log density formula
}

# The full E step in log space
# Returns responsibilities r (n x K) and per observation log-likelihood ell
estep_log <- function(X, pie_k, mu, Sigma) {
  n <- nrow(X); K <- length(pie_k)                                              # n observations, K mixture components
  lw <- matrix(0, n, K)                                                         # will hold log(pi_k) + log N(x_i | mu_k, Sigma_k)
  for (k in 1:K) {
    lw[, k] <- log(pie_k[k] + 1e-300) +                                         # log of the mixing weight
      log_dmvn(X, mu[k, ], matrix(Sigma[, , k], ncol(X), ncol(X)))              # log density of component k at every point
  }
  mx  <- apply(lw, 1, max)                                                      #the log-sum-exp shift constant
  ell <- mx + log(rowSums(exp(lw - mx)))                                        # log-sum-exp -> per-observation log-likelihood log p(x_i)
  r   <- exp(lw - ell)                                                          #Responsibilities
  list(r = r, ell = ell)
}

# This exact the rank-based trimming: flag the cut lowest likelihood points
# Return V( 1= keep ) and the implied lambda for reporting.
V_from_prop <- function(ell, cut) {
  n <- length(ell)                                                              # number of observations
  m <- floor(cut * n)                                                           # how many points to flag as contamination
  m <- max(0L, min(as.integer(m), n))                                           # clamp into [0, n] so a bad `cut` can't break things
  V <- rep(1L, n)                                                               # start with everything kept (1 = keep)
  if (m > 0L) {
    drop_idx <- order(ell, decreasing = FALSE)[seq_len(m)]                      # indices of the m smallest log-likelihoods
    V[drop_idx] <- 0L                                                           # mark those as flagged (0 = discard)
  }
  lambda <- if (m == 0L) -Inf else max(ell[V == 0L])                            #highest ell among discarded points
  list(V = V, lambda = lambda)
  
}

#### ---- eigenvalue-ratio constraint -------------------------------------------
# The mixture likelihood is unbounded: one component can spread out to blanket
# the noise, or collapse onto a handful of points, and both raise the
# likelihood without describing anything. This caps the ratio of largest to
# smallest eigenvalue ACROSS all components, the standard TCLUST-style
# restriction that makes the problem well posed.
#
# The clamp is anchored on the GEOMETRIC MEAN eigenvalue rather than on the
# smallest one: anchoring on the smallest would let a single collapsed
# component drag every other component down with it.
#
# ratio = Inf disables the constraint entirely.
################################################################################

constrain_sigma <- function(Sigma, ratio = Inf) {
  
  if (!is.finite(ratio) || ratio <= 1) return(Sigma)                            # disabled
  d <- dim(Sigma)[1]; K <- dim(Sigma)[3]
  if (anyNA(Sigma)) return(Sigma)
  
  eigs <- lapply(seq_len(K), function(k)
    eigen(0.5 * (Sigma[, , k] + t(Sigma[, , k])), symmetric = TRUE))            # symmetrise first, guard against drift
  
  all_val <- unlist(lapply(eigs, function(e) e$values))
  all_val <- all_val[is.finite(all_val) & all_val > 0]
  if (!length(all_val)) return(Sigma)
  
  g  <- exp(mean(log(all_val)))                                                 # typical scale, robust to one wild component
  lo <- g / sqrt(ratio)                                                         # so hi / lo == ratio exactly
  hi <- g * sqrt(ratio)
  
  for (k in seq_len(K)) {
    v <- pmin(pmax(eigs[[k]]$values, lo), hi)                                   # clamp every eigenvalue into [lo, hi]
    Sigma[, , k] <- eigs[[k]]$vectors %*% diag(v, d, d) %*% t(eigs[[k]]$vectors)
  }
  Sigma
}

################################################################################
##  2. DATA GENERATION
################################################################################
# n:      number of points
# pie:    mixing weights (length K, normalised internally)
# mu:     component means (K x d)
# Sigma:  covariances (d x d x K)
# alpha:  contamination fraction in [0, 1]
# bounds: range of the uniform noise
################################################################################

rGMM <- function(n, pie, mu, Sigma, alpha = 0, bounds = c(-10, 10), seed = NULL) {
  
  if (!is.null(seed)) set.seed(seed)                                            # fix the RNG for reproducibility if a seed is given
  pie <- as.numeric(pie); pie <- pie / sum(pie)                                 # Coerce and normalise mixing weights to sum to 1
  mu  <- as.matrix(mu)                                                          # K x d matrix of component means
  K   <- length(pie)                                                            # Number of components
  d   <- ncol(mu)                                                               # Dimensionality
  Sigma <- array(Sigma, dim = c(d, d, K))                                       # Coerce covariances into a d x d x K array
  
  labels <- sample.int(K, size = n, replace = TRUE, prob = pie)
  
  chols <- lapply(1:K, function(k) chol(matrix(Sigma[, , k], d, d) + diag(1e-8, d)))
  
  X <- matrix(NA_real_, n, d)                                                   #Pre allocate the data matrix
  for (k in 1:K) {
    idx <- which(labels == k)                                                   #rows assigned to component k
    if (!length(idx)) next
    Z <- matrix(rnorm(length(idx) * d), nrow = length(idx), ncol = d)           # iid standard normals
    X[idx, ] <- sweep(Z %*% chols[[k]], 2, mu[k, ], "+")                        # Z %*% R has covariance t(R)R = Sigma;
  }
  
  m <- floor(alpha * n)                                                         #number of points to contaminate
  contam_idx <- integer(0)                                                      #default is none
  if (m > 0) {
    contam_idx <- sample.int(n, m)                                              #choose which rows get replaced
    X[contam_idx, ] <- matrix(runif(m * d, bounds[1], bounds[2]), nrow = m, ncol = d)
    labels[contam_idx] <- 0L                                                    #label 0 marks contamination, used later for scoring
  }
  
  list(X = X, labels = labels, contam_idx = contam_idx)
}

################################################################################
#    3. Main routine: SPL-EM
################################################################################
# X            data matrix (n x d)
# pie, mu, Sigma   initial values
# prop_cut     STARTING trimming proportion (conservative: trim a lot early)
# target_cut   FINAL trimming proportion (set near the expected contamination)
# cut_decay    geometric rate at which prop_cut anneals toward target_cut
# eig_ratio    cap on the eigenvalue ratio across components; Inf = off
# max_outer / max_inner / tol   loop controls
#
# cut_t = target + (prop_cut - target) * (1 - cut_decay)^(t-1)
# so the trimming level converges to target_cut instead of drifting to zero.
# The schedule only does useful work when prop_cut > target_cut: trim hard
# while the parameters are still poor, relax as they improve.
################################################################################

gmm_em_spl <- function(X, pie, mu, Sigma,
                       prop_cut   = 0.5,
                       target_cut = NULL,
                       cut_decay  = 0.05,
                       eig_ratio  = Inf,
                       max_outer  = 300,                                        #enough for the annealing schedule to arrive
                       max_inner  = 100,
                       tol        = 1e-6,
                       verbose    = FALSE) {
  
  ## ---- set-up ----------------------------------------------------------
  if (is.null(dim(X))) X <- matrix(X, ncol = 1)                                 #treat a bare vector as univariate data
  X <- as.matrix(X)
  n <- nrow(X); d <- ncol(X); K <- length(pie)                                  #sample size, dimension, number of components
  
  pie_k <- as.numeric(pie); pie_k <- pie_k / sum(pie_k)                         #copy of mixing weights, normalised
  mu    <- as.matrix(mu)                                                        #copy of the means
  Sigma <- array(Sigma, dim = c(d, d, K))                                       #copy of the covariances
  Sigma <- constrain_sigma(Sigma, eig_ratio)                                    #a wild starting covariance cannot dominate iteration 1
  
  if (is.null(target_cut)) target_cut <- prop_cut                               # no annealing by default
  
  # never trim so hard that a component cannot be estimated
  cut_ceiling <- 1 - (K * (d + 1) + 1) / n                                      #keep at least enough points to identify K means + K variances
  prop_cut    <- min(max(prop_cut,   0), cut_ceiling)
  target_cut  <- min(max(target_cut, 0), cut_ceiling)
  
  snap_tol <- 0.5 / n
  
  ## ---- state -----------------------------------------------------------
  V_prev    <- rep(1L, n)                                                       #From previous iteration, checking for stability
  ll_prev   <- -Inf                                                             #trimmed log-likelihood from outer iteration
  lambda    <- -Inf                                                             #current implied threshold
  hist_cut  <- numeric(0)                                                       #trace of the trimming level per outer iteration
  hist_ll   <- numeric(0)                                                       #trace of the trimmed log likelihood per outer iteration
  it_inner  <- 0L                                                               #initialised so it exists even if a loop never runs
  converged <- FALSE                                                            #set TRUE if the outer loop breaks on the convergence test
  
  ## ---- OUTER LOOP: update the SPL weights V ----------------------------
  for (it_outer in 1:max_outer) {
    
    cut_t <- target_cut + (prop_cut - target_cut) * (1 - cut_decay)^(it_outer - 1)
    if (abs(cut_t - target_cut) < snap_tol) cut_t <- target_cut                 # snap once the trim COUNT can no longer differ
    
    E   <- estep_log(X, pie_k, mu, Sigma)                                       # Responsibilities and per point log likelihood
    trm <- V_from_prop(E$ell, cut_t)                                            # trim the worst cut_t proportion by log-likelihood
    V      <- trm$V                                                             # binary keep/discard indicator
    lambda <- trm$lambda                                                        # the threshold this trimming implies
    
    min_keep <- K * (d + 1) + 1                                                 
    if (sum(V) < min_keep) {                                                   
      keep <- order(E$ell, decreasing = TRUE)[seq_len(min_keep)]                
      V <- as.integer(seq_len(n) %in% keep)                                     
    }
    
    ## ---- INNER LOOP: EM with V fixed ----------------------------------
    ll_in_prev <- -Inf
    for (it_inner in 1:max_inner) {
      
      # E-step (at current params) -> likelihood -> convergence -> M-step,
      # so the likelihood always matches the parameters it is reported for
      E  <- estep_log(X, pie_k, mu, Sigma)                                      #responsibilities at the current parameters
      ll <- sum(E$ell[V == 1L])                                                 # trimmed log-likelihood
      
      if (is.finite(ll_in_prev) &&
          abs(ll - ll_in_prev) < tol * (abs(ll_in_prev) + 1)) break             #Relative tolerance
      ll_in_prev <- ll                                                          #store for the next comparison
      
      # --- M-step, responsibilities masked by the SPL weights
      w  <- E$r * V                                                             #V recycled column wise; flagged rows get weight 0 in every component
      Nk <- colSums(w)                                                          # effective number of kept points assigned to each component
      
      pie_k <- (Nk + 1e-12) / sum(Nk + 1e-12)                                   #updating the mixing weights
      
      for (k in 1:K) {
        if (Nk[k] <= 1e-8) next                                                 # leave an empty component alone
        mu[k, ] <- colSums(w[, k] * X) / Nk[k]                                  # weighted mean: sum_i w_ik x_i / sum_i w_ik
        Xc <- sweep(X, 2, mu[k, ], "-")                                         #center on the updated mean
        Sigma[, , k] <- crossprod(Xc, w[, k] * Xc) / Nk[k] + diag(1e-6, d)      #diag(1e-6, d) is a ridge that stops Sigma going singular
      }
      
      Sigma <- constrain_sigma(Sigma, eig_ratio)                                #no component may blanket the noise or collapse to a point
    }
    
    hist_cut <- c(hist_cut, cut_t)                                              #record the trimming level
    hist_ll  <- c(hist_ll,  ll)                                                 #record the resulting trimmed log likelihood
    
    if (verbose) {
      cat(sprintf("outer %3d | cut = %.3f | kept = %4d | lambda = %8.3f | ll = %12.3f\n",
                  it_outer, cut_t, sum(V), lambda, ll))                         # one diagnostic line per outer iteration
    }
    
    schedule_done <- abs(cut_t - target_cut) < snap_tol                         # outer convergence test
    if (schedule_done && identical(V, V_prev) &&                                #flagged set stops changing
        is.finite(ll_prev) && abs(ll - ll_prev) < tol * (abs(ll_prev) + 1)) {   #likelihood stable
      converged <- TRUE
      break
    }
    V_prev  <- V
    ll_prev <- ll
  }
  
  ## ---- final E-step so labels / responsibilities match final params ----
  E      <- estep_log(X, pie_k, mu, Sigma)                                      #recompute at the converged parameters
  trm    <- V_from_prop(E$ell, target_cut)                                      #final trimming at the target level
  V      <- trm$V
  lambda <- trm$lambda
  ll     <- sum(E$ell[V == 1L])                                                 #final trimmed log likelihood
  
  labels <- apply(E$r, 1, which.max)                                            #hard assignment (each point to its most probable component)
  labels[V == 0L] <- 0L
  
  list(pie              = pie_k,                                                #estimated mixing weights
       mu               = mu,                                                   #estimated means
       Sigma            = Sigma,                                                #estimated covariances
       responsibilities = E$r,                                                  #soft assignments
       ell              = E$ell,                                                # per-observation log-likelihoods
       labels           = labels,                                               #hard labels
       V                = V,                                                    # 1 = kept, 0 = flagged as contamination
       lambda           = lambda,                                               # implied threshold at the final trim level
       loglik           = ll,                                                   # TRIMMED log-lik at the returned params
       converged        = converged,                                            # outer loop met the convergence test
       eig_ratio        = eig_ratio,
       history          = list(cut = hist_cut, loglik = hist_ll),               #trace for plotting
       iters            = list(outer = it_outer, inner = it_inner))
}


################################################################################
##  4. PLOTTING
################################################################################

plt_gmm <- function(X, fit, level = 0.95, V = NULL, legend_pos = "topright",
                    main = NULL) {
  
  X <- as.matrix(X)
  stopifnot(ncol(X) == 2)
  K <- nrow(fit$mu)
  
  if (is.null(V)) V <- if (!is.null(fit$V)) fit$V else rep(1L, nrow(X))
  V <- as.integer(V > 0)
  stopifnot(length(V) == nrow(X))
  
  labels <- if (!is.null(fit$labels)) fit$labels else rep(1L, nrow(X))
  
  base_cols <- c("red3", "deeppink", "darkorange", "purple3", "navy", "firebrick3")
  comp_cols <- base_cols[(seq_len(K) - 1) %% length(base_cols) + 1]
  
  pt_cols <- rep(NA_character_, length(labels))
  for (k in 1:K) pt_cols[labels == k] <- comp_cols[k]
  pt_cols[labels == 0] <- "forestgreen"
  
  rx <- range(X[, 1]); ry <- range(X[, 2])
  padx <- 0.1 * diff(rx); pady <- 0.1 * diff(ry)
  
  plot(X, pch = 16, cex = 0.6, col = pt_cols,
       xlim = c(rx[1] - padx, rx[2] + padx),
       ylim = c(ry[1] - pady, ry[2] + pady),
       xlab = "X1", ylab = "X2",
       main = if (is.null(main))
         sprintf("SPL-EM GMM (%.0f%% ellipses; V == 0 marked)", 100 * level) else main)
  
  c2   <- qchisq(level, df = 2)
  th   <- seq(0, 2 * pi, length.out = 200)
  unit <- rbind(cos(th), sin(th))
  
  for (k in 1:K) {
    S  <- 0.5 * (fit$Sigma[, , k] + t(fit$Sigma[, , k]))
    eg <- eigen(S, symmetric = TRUE)
    A  <- eg$vectors %*% diag(sqrt(pmax(eg$values, 0) * c2), 2, 2)
    E  <- t(A %*% unit)
    lines(E[, 1] + fit$mu[k, 1], E[, 2] + fit$mu[k, 2],
          lty = 2, lwd = 1.4, col = comp_cols[k])
  }
  
  points(fit$mu[, 1], fit$mu[, 2], pch = 4, cex = 1.5, lwd = 2, col = "black")
  
  bad <- which(V == 0)
  if (length(bad) > 0)
    points(X[bad, 1], X[bad, 2], pch = 4, col = "forestgreen", lwd = 1.6, cex = 1.0)
  
  counts  <- tabulate(labels, nbins = K)
  leg_txt <- paste0("Comp ", seq_len(K), " (n=", counts, ")")
  leg_col <- comp_cols
  leg_pch <- rep(16, K)
  
  if (length(bad) > 0) {
    leg_txt <- c(leg_txt, sprintf("Flagged (V=0, n=%d)", length(bad)))
    leg_col <- c(leg_col, "forestgreen")
    leg_pch <- c(leg_pch, 4)
  }
  
  leg_txt <- c(leg_txt, "Component ellipse")
  leg_col <- c(leg_col, "black")
  leg_pch <- c(leg_pch, NA)
  leg_lty <- c(rep(NA, length(leg_txt) - 1), 2)
  
  legend(legend_pos, legend = leg_txt, col = leg_col, pch = leg_pch,
         lty = leg_lty, pt.cex = 0.9, cex = 0.85, bty = "n", lwd = 1.4)
  
  invisible(NULL)
}


################################################################################
##  5. EVALUATION
################################################################################

eval_fit <- function(sim, fit) {
  n        <- nrow(sim$X)
  is_true  <- rep(FALSE, n); is_true[sim$contam_idx] <- TRUE                    #which points really are contaminated
  is_flag  <- fit$V == 0L                                                       #what the fit flagged
  
  TP <- sum(is_flag &  is_true)                                                 #flagged and genuinely contaminated
  FP <- sum(is_flag & !is_true)                                                 #flagged but actually clean
  FN <- sum(!is_flag &  is_true)                                                #missed contamination
  
  precision <- if (TP + FP > 0) TP / (TP + FP) else NA_real_                    #of what is flagged, how much was real
  recall    <- if (TP + FN > 0) TP / (TP + FN) else NA_real_                    #of the real contamination, how much was caught
  f1        <- if (!is.na(precision) && !is.na(recall) && precision + recall > 0)
    2 * precision * recall / (precision + recall) else NA_real_                 #harmonic mean of the two
  
  list(TP = TP, FP = FP, FN = FN,
       precision = precision, recall = recall, f1 = f1)
}

## ---- geometry of a fit: the check that catches collapsed clusters ----------
min_sep <- function(mu) {                                                       # smallest distance between any two component means
  mu <- as.matrix(mu)
  if (nrow(mu) < 2 || anyNA(mu)) return(NA_real_)
  min(dist(mu))
}

comp_trace <- function(Sigma) {                                                 # average variance per component
  if (anyNA(Sigma)) return(rep(NA_real_, dim(Sigma)[3]))
  vapply(seq_len(dim(Sigma)[3]), function(k) mean(diag(Sigma[, , k])), numeric(1))
}

ellipses_overlap <- function(mu, Sigma, level = 0.95) {                         # centres closer than the two major radii
  mu <- as.matrix(mu)
  if (anyNA(mu) || anyNA(Sigma) || nrow(mu) < 2) return(NA)
  c2  <- qchisq(level, df = ncol(mu))
  rad <- vapply(seq_len(dim(Sigma)[3]), function(k)
    sqrt(max(eigen(Sigma[, , k], symmetric = TRUE, only.values = TRUE)$values) * c2),
    numeric(1))
  D <- as.matrix(dist(mu))
  any(sapply(seq_len(nrow(mu) - 1), function(i)
    any(D[i, (i + 1):nrow(mu)] < rad[i] + rad[(i + 1):nrow(mu)])))
}


################################################################################
#  The 6.Initialisation 
################################################################################
init_tkmeans <- function(X, K, seed = NULL, trim = 0.05,
                         nstart = 20, iter_max = 30, ...) {
  
  X <- as.matrix(X); n <- nrow(X); d <- ncol(X)
  trim <- min(max(trim, 0), 0.9)
  if (!is.null(seed)) set.seed(seed)
  
  n_keep <- max(K * (d + 1) + 1, n - floor(trim * n))
  n_keep <- min(n_keep, n)
  
  best <- NULL
  for (s in seq_len(nstart)) {
    
    ctr <- X[sample.int(n, K), , drop = FALSE]
    D <- matrix(0, n, K); cl <- integer(n); keep <- rep(TRUE, n)
    
    for (it in seq_len(iter_max)) {
      for (k in seq_len(K)) D[, k] <- colSums((t(X) - ctr[k, ])^2)
      cl <- max.col(-D, ties.method = "first")
      dm <- D[cbind(seq_len(n), cl)]
      
      keep <- rep(FALSE, n)
      keep[order(dm)[seq_len(n_keep)]] <- TRUE
      
      ctr_new <- ctr
      for (k in seq_len(K)) {
        idx <- which(keep & cl == k)
        if (length(idx)) ctr_new[k, ] <- colMeans(X[idx, , drop = FALSE])
      }
      if (max(abs(ctr_new - ctr)) < 1e-8) { ctr <- ctr_new; break }
      ctr <- ctr_new
    }
    
    obj <- sum(D[cbind(seq_len(n), cl)][keep])
    if (is.null(best) || obj < best$obj)
      best <- list(obj = obj, ctr = ctr, cl = cl, keep = keep)
  }
  
  cl  <- best$cl; keep <- best$keep
  mu  <- matrix(as.numeric(best$ctr), K , d)
  pie <- vapply(seq_len(K), function(k) sum(keep & cl == k), numeric(1))
  pie <- pie / max(sum(pie), 1)
  pie[pie <= 0] <- 1e-8; pie <- pie/ sum(pie)
  
  S_pool <- cov(X[keep, , drop = FALSE]) + diag(1e-6, d)
  Sigma  <- array(0, c(d, d, K))
  for (k in seq_len(K)) {
    idx <- which(keep & cl == k)
    Sigma[, , k] <- if (length(idx) > d) cov(X[idx, , drop = FALSE]) + diag(1e-6, d) else S_pool
  }
  
  z <- matrix(0, n, K)
  z[cbind(seq_len(n), cl)] <- 1
  
  list(pie = pie, mu = mu, Sigma = Sigma, z = z, cluster = cl,
       kept = keep, trim = trim, tot_withinss = best$obj, init = "tkmeans")
}

################################################################################
#   Classical EM via mclust 
################################################################################

ensure_mclust <- function(){
  if(!requireNamespace("mclust", quietly = TRUE))
  stop("Install mclust first: install.packages(\"mclust\")")
  if(! "package:mclust" %in% search())
  suppressPackageStartupMessages(library(mclust))
  invisible(TRUE)
}

mclust_sigma_array <- function(v, d, K){
  if (!is.null(v$sigma)) return(array(v$sigma, c(d,d,K)))
  if (!is.null(v$Sigma)) return(array(rep(as.numeric(v$Sigma), K), c(d, d, K)))
  if (!is.null(v$sigmasq)){
    s2 <- rep_len(as.numeric(v$sigmasq), K)
    out <- array(0, c(d, d, K))
    for (k in seq_len(K)) out[, , k] <- diag(s2[k], d)
    return(out)
    
  }
  array(NA_real_, c(d, d, K))
}

fit_em <- function(X, init, modelName ="VVV"){
  ensure_mclust()
  if(is.null(init$z)) stop("fit_em needs a z matrix.")
  X <- as.matrix(X); d <-ncol(X); K <-ncol(init$z)
  
  na_fit <- list(pie   = rep(NA_real_, K), mu = matrix(NA_real_, K, d),
                 Sigma = array(NA_real_, c(d, d, K)),
                 loglik = NA_real_, converged = FALSE,          # <- was NA_real
                 modelName = modelName, method = "EM",
                 init = if (is.null(init$init)) NA_character_ else init$init)
  
  em <- tryCatch(mclust::me(data = X, modelName = modelName, z = init$z),
                 error = function(e) NULL)
  
  if(is.null(em) || is.null(em$parameters) || !is.finite(em$loglik)) return(na_fit)
  mu <- t(matrix(as.numeric(em$parameters$mean), d, K))
  
  list(pie       = as.numeric(em$parameters$pro),
       mu        = mu,
       Sigma     = mclust_sigma_array(em$parameters$variance, d, K),
       loglik    = as.numeric(em$loglik),
       converged = is.null(attr(em, "warn")),
       modelName = modelName,
       method    = "EM",
       init      = if (is.null(init$init)) NA_character_ else init$init)
}

################################################################################
#     8. Real data helper 
################################################################################

npar_VVV <- function(K,d) (K - 1) + K * d + K * d * (d + 1) / 2
bic_from <- function(loglik, npar, n) -2 *loglik + npar * log(n)

fit_em_K <- function(X, init, K){
  X <- as.matrix(X); n <- nrow(X); d <- ncol(X)
  if (K == 1L) {
    mu    <- matrix(colMeans(X), 1, d)
    Sigma <- array(cov(X) * (n - 1) / n, c(d, d, 1))
    ll    <- sum(log_dmvn(X, mu[1, ], Sigma[, , 1]))
    return(list(pie = 1, mu = mu, Sigma = Sigma, loglik = ll,
                converged = TRUE, method = "EM"))
  }
  fit_em(X, init, modelName = "VVV")
}
unscale_mu <- function(mu, centre, scl) sweep(sweep(mu, 2, scl, "*"), 2 ,centre, "+")
unscale_Sigma <- function(Sigma, scl){
  D <- diag(scl, length(scl))
  for (k in seq_len(dim(Sigma)[3])) Sigma[, , k] <- D %*% Sigma[, , k] %*% D
  Sigma

}

`%||%` <- function(a, b) if (is.null(a)) b else a
 
  