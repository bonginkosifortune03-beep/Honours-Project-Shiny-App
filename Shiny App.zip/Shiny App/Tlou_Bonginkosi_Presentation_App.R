################################################################################
#  Shiny app: Robust Gaussian mixture fitting, EM vs SPL                       #
#  Presentation version - tabs follow the research report section numbering    #
#                                                                              #
#  Tlou Bonginkosi Fortune                                                     #
#  Run with: shiny::runApp("Tlou_Bonginkosi_Presentation_App.R")               #
#  Requires gmm_spl_core.R in the same working directory.                      #
################################################################################

library(shiny)
library(mclust)
source("gmm_spl_core.R")

`%||%` <- function(a, b) if (is.null(a)) b else a

## Colour palette ------------------------------------------------------------
## EM is red and SPL is blue everywhere: navbar, cards, plots and tables.
COL_EM  <- "#B03A2E"
COL_SPL <- "#1F3A6E"

################################################################################
#  Styling                                                                     #
################################################################################

app_css <- "
:root {
  --em:     #B03A2E;
  --spl:    #1F3A6E;
  --ink:    #1C2733;
  --muted:  #5A6673;
  --line:   #DEE4EA;
  --page:   #F4F6F8;
  --card:   #FFFFFF;
  --accent: #E8A33D;
}

body { background: var(--page); color: var(--ink);
       font-family: 'Segoe UI', 'Helvetica Neue', Arial, sans-serif; }

/* ---- navbar ---- */
.navbar-default {
  background: var(--spl); border: none; border-radius: 0;
  margin-bottom: 0; box-shadow: 0 2px 6px rgba(0,0,0,.18);
}
.navbar-default .navbar-brand { color: #fff; font-weight: 600; font-size: 17px; }
.navbar-default .navbar-brand:hover { color: #fff; }
.navbar-default .navbar-nav > li > a {
  color: #C9D4E6; font-weight: 500; letter-spacing: .2px;
}
.navbar-default .navbar-nav > li > a:hover {
  color: #fff; background: rgba(255,255,255,.08);
}
.navbar-default .navbar-nav > .active > a,
.navbar-default .navbar-nav > .active > a:hover,
.navbar-default .navbar-nav > .active > a:focus {
  background: rgba(255,255,255,.16); color: #fff;
  border-bottom: 3px solid var(--accent);
}

/* ---- one shared container so every section lines up ---- */
.section-wrap { max-width: 1180px; margin: 0 auto; padding: 0 16px 40px 16px; }
.head-wrap    { max-width: 1180px; margin: 0 auto 22px auto; padding: 0 16px; }

/* ---- section header band ---- */
.section-head {
  background: linear-gradient(100deg, var(--spl) 0%, #2C5086 100%);
  color: #fff; padding: 20px 26px; border-radius: 0 0 6px 6px;
  box-shadow: 0 2px 5px rgba(0,0,0,.10);
}
.section-head .num {
  display: inline-block; background: var(--accent); color: #23303D;
  width: 34px; height: 34px; line-height: 34px; text-align: center;
  border-radius: 50%; font-weight: 700; margin-right: 13px; font-size: 16px;
}
.section-head h2 { display: inline; font-size: 23px; font-weight: 600;
                   margin: 0; vertical-align: middle; }
.section-head .sub { margin: 9px 0 0 47px; color: #C3D0E3; font-size: 12.5px; }

/* ---- cards ---- */
.card {
  background: var(--card); border: 1px solid var(--line); border-radius: 6px;
  padding: 18px 22px; margin-bottom: 18px;
  box-shadow: 0 1px 3px rgba(16,24,32,.05);
}
.card h3 { margin-top: 0; font-size: 16.5px; font-weight: 600;
           color: var(--spl); border-bottom: 2px solid var(--line);
           padding-bottom: 8px; margin-bottom: 13px; }
.card ul, .card ol { padding-left: 20px; margin-bottom: 0; }
.card li { margin-bottom: 7px; line-height: 1.6; }
.card p  { line-height: 1.65; }

/* equal-height cards in a row */
.row-flex { display: flex; flex-wrap: wrap; }
.row-flex > div { display: flex; }
.row-flex .card { flex: 1; }

/* ---- equation block ---- */
.eqn {
  background: #F7F9FB; border-left: 4px solid var(--spl);
  padding: 4px 18px; margin: 13px 0; border-radius: 0 4px 4px 0;
  overflow-x: auto;
}

/* ---- callouts ---- */
.note {
  background: #FFF6E5; border-left: 4px solid var(--accent);
  padding: 12px 16px; margin: 14px 0 0 0; border-radius: 0 4px 4px 0;
  font-size: 13.5px; line-height: 1.6;
}
.keypoint {
  background: #EDF2F9; border-left: 4px solid var(--spl);
  padding: 12px 16px; margin: 14px 0 0 0; border-radius: 0 4px 4px 0;
  line-height: 1.6;
}
.keypoint ul { margin-bottom: 0; padding-left: 20px; }

/* ---- method colour chips ---- */
.chip { display:inline-block; padding:2px 11px; border-radius:11px;
        font-size:12px; font-weight:600; color:#fff; margin-right:5px; }
.chip-em  { background: var(--em); }
.chip-spl { background: var(--spl); }

/* ---- sidebar ---- */
.well {
  background: var(--card); border: 1px solid var(--line);
  border-top: 4px solid var(--spl); border-radius: 6px;
  box-shadow: 0 1px 3px rgba(16,24,32,.05); padding: 16px 18px;
}
.well h4 { margin-top: 0; font-size: 13px; font-weight: 700;
           color: var(--spl); text-transform: uppercase;
           letter-spacing: .5px; border-bottom: 1px solid var(--line);
           padding-bottom: 7px; }
.well label { font-size: 13px; font-weight: 600; color: var(--ink); }
.btn-primary {
  background: var(--spl); border-color: var(--spl);
  font-weight: 600; width: 100%;
}
.btn-primary:hover, .btn-primary:focus {
  background: #16294E; border-color: #16294E;
}
.btn-default { width: 100%; font-weight: 600;
               border-color: var(--spl); color: var(--spl); }

/* ---- inner tabs ---- */
.nav-tabs { border-bottom: 2px solid var(--line); margin-bottom: 0; }
.nav-tabs > li > a {
  color: var(--muted); font-weight: 500; border: none;
  border-bottom: 3px solid transparent; margin-right: 4px;
}
.nav-tabs > li > a:hover { background: #E9EDF2; border-color: transparent; }
.nav-tabs > li.active > a,
.nav-tabs > li.active > a:hover,
.nav-tabs > li.active > a:focus {
  color: var(--spl); font-weight: 600; background: var(--card);
  border: none; border-bottom: 3px solid var(--spl);
}
.tab-content {
  background: var(--card); border: 1px solid var(--line); border-top: none;
  border-radius: 0 0 6px 6px; padding: 18px 20px;
}

/* ---- console output ---- */
pre {
  background: #FAFBFC; border: 1px solid var(--line); border-radius: 4px;
  font-size: 12.5px; line-height: 1.55; color: #2A3744;
}

/* ---- tables ---- */
.table { background: var(--card); font-size: 13px; width: 100%; }
.table > thead > tr > th {
  background: var(--spl); color: #fff; font-weight: 600;
  border: none; text-align: center; vertical-align: middle;
}
.table > tbody > tr > td { text-align: center; vertical-align: middle; }
.table > tbody > tr:nth-child(odd) { background: #F7F9FB; }

/* ---- footer ---- */
.app-footer {
  background: var(--spl); color: #9FB0C9; text-align: center;
  padding: 14px; font-size: 12px; margin-top: 30px;
}
"

## Layout helpers ------------------------------------------------------------

section_head <- function(num, title, sub = NULL) {
  tags$div(
    class = "head-wrap",
    tags$div(
      class = "section-head",
      tags$span(class = "num", num),
      tags$h2(title),
      if (!is.null(sub)) tags$div(class = "sub", sub)
    )
  )
}

section_body <- function(...) tags$div(class = "section-wrap", ...)

eqn <- function(...) tags$div(class = "eqn", ...)

################################################################################
#  Static results from the simulation study (Table 1 of the report)            #
################################################################################

sim_table <- data.frame(
  Contamination = rep(c("0%", "5%", "10%"), each = 5),
  Parameter = rep(c("mu_11", "mu_21", "mu_12", "mu_22", "pi_1"), 3),
  Bias_SPL = c(
    0.002322, 0.002278, 0.001431, 0.001738, 0.000000,
    0.003653, 0.003038, 0.000782, 0.001540, 0.000446,
    0.002614, 0.000072, 0.000109, -0.000810, 0.001520),
  Bias_EM = c(
    0.002323, 0.002280, 0.001432, 0.001740, 0.000000,
    -0.021537, -0.057469, -0.027099, -0.050003, -0.016630,
    -0.050832, -0.463821, -0.053172, -0.453166, -0.055368),
  MSE_SPL = c(
    0.002932, 0.006272, 0.002898, 0.006936, 0.000402,
    0.003256, 0.007330, 0.003061, 0.007875, 0.000427,
    0.003365, 0.008312, 0.003483, 0.009130, 0.000484),
  MSE_EM = c(
    0.002932, 0.006273, 0.002898, 0.006936, 0.000402,
    0.004840, 0.031608, 0.004905, 0.032835, 0.000678,
    0.007884, 0.436745, 0.008405, 0.427516, 0.003898),
  stringsAsFactors = FALSE
)

################################################################################
#  UI                                                                          #
################################################################################

ui <- navbarPage(
  title = "Robust Gaussian mixture modeling using Self-Paced Learning ",
  id = "nav",
  collapsible = TRUE,

  header = tagList(
    withMathJax(),
    tags$head(tags$style(HTML(app_css)))
  ),

  footer = tags$div(
    class = "app-footer",
    "Tlou Bonginkosi Fortune  |  Supervisor: Andre Kleynhans  |  ",
    "Department of Statistics, University of Pretoria"
  ),

  ## ---- Section 1 ------------------------------------------------------- ##
  tabPanel(
    "1. Introduction",
    section_head(1, "Introduction", "Report Section 1, page 5"),
    section_body(
      tags$div(
        class = "row row-flex",
        tags$div(class = "col-sm-6", tags$div(
          class = "card",
          tags$h3("The problem"),
          tags$ul(
            tags$li("Clustering finds the underlying structure of unlabelled data."),
            tags$li(HTML("Data are often assumed to come from a <b>Gaussian
                          mixture model</b>, fitted by the <b>EM algorithm</b>.")),
            tags$li(HTML("EM is <b>not robust</b>: a small fraction of
                          non-typical observations distorts the estimates.")),
            tags$li(HTML("Heavy-tailed alternatives reduce the influence but
                          still keep outlying observations in the likelihood."))
          )
        )),
        tags$div(class = "col-sm-6", tags$div(
          class = "card",
          tags$h3("The proposal"),
          tags$p(HTML("<b>Self-paced learning (SPL)</b> admits observations into
                       the estimation process in order of how typical they are,
                       so that gross outliers are <i>excluded</i> rather than
                       <i>accommodated</i>.")),
          tags$div(class = "keypoint",
                   HTML("<b>Aim.</b> Investigate SPL as a robust estimation
                         strategy for the GMM, comparing it against classical EM
                         on simulated and real data."))
        ))
      ),
      tags$div(
        class = "card",
        tags$h3("How the two methods are compared"),
        tags$p(HTML(paste0(
          "<span class='chip chip-em'>EM</span> uses every observation in every ",
          "update.&nbsp;&nbsp;&nbsp; ",
          "<span class='chip chip-spl'>SPL</span> uses only the currently ",
          "admitted subset."))),
        tags$p("Both are given the same trimmed k-means starting values on every
                fit, so any difference in the estimates comes from the trimming
                and not from the start point.")
      )
    )
  ),

  ## ---- Section 2 ------------------------------------------------------- ##
  tabPanel(
    "2. GMM",
    section_head(2, "Gaussian Mixture Model", "Report Section 2, page 6"),
    section_body(
      tags$div(
        class = "card",
        tags$h3("The model"),
        tags$p(HTML("Let \\(\\boldsymbol{X} \\in \\mathbb{R}^d\\) follow a
                     \\(K\\)-component Gaussian mixture. Its density is")),
        eqn("$$f(\\boldsymbol{x}) = \\sum_{k=1}^{K} \\pi_k \\,
             N(\\boldsymbol{x} \\mid \\boldsymbol{\\mu}_k,
             \\boldsymbol{\\Sigma}_k),$$"),
        tags$p("where"),
        eqn("$$N(\\boldsymbol{x} \\mid \\boldsymbol{\\mu}_k,
             \\boldsymbol{\\Sigma}_k)
             = \\frac{1}{(2\\pi)^{d/2} |\\boldsymbol{\\Sigma}_k|^{1/2}}
             \\exp\\!\\left(-\\tfrac{1}{2}
             (\\boldsymbol{x}-\\boldsymbol{\\mu}_k)^{\\top}
             \\boldsymbol{\\Sigma}_k^{-1}
             (\\boldsymbol{x}-\\boldsymbol{\\mu}_k)\\right).$$")
      ),
      tags$div(
        class = "card",
        tags$h3("Complete-data log-likelihood"),
        eqn("$$\\ell_c(\\boldsymbol{\\Theta}) = \\sum_{i=1}^{N}\\sum_{k=1}^{K}
             z_{ik}\\left[\\log \\pi_k + \\log N(\\boldsymbol{x} \\mid
             \\boldsymbol{\\mu}_k, \\boldsymbol{\\Sigma}_k)\\right]$$"),
        tags$div(class = "keypoint",
                 HTML("\\(z_{ik}=1\\) if observation \\(i\\) was generated by the
                       \\(k\\)th component, and 0 otherwise. The \\(z_{ik}\\) are
                       <b>unobserved</b>, which is why EM is needed."))
      )
    )
  ),

  ## ---- Section 3 ------------------------------------------------------- ##
  tabPanel(
    "3. EM Algorithm",
    section_head(3, "Expectation Maximisation Algorithm",
                 "Report Section 3, page 7; derivations in Appendix A"),
    section_body(
      tags$div(
        class = "row row-flex",
        tags$div(class = "col-sm-6", tags$div(
          class = "card",
          tags$h3("E-step"),
          eqn("$$p_{ik}^{(new)} = \\frac{\\pi_k^{(old)}
               f_k(\\boldsymbol{x}_i \\mid \\boldsymbol{\\theta}_k^{(old)})}
               {\\sum_{j=1}^{K} \\pi_j^{(old)}
               f_j(\\boldsymbol{x}_i \\mid \\boldsymbol{\\theta}_j^{(old)})}$$")
        )),
        tags$div(class = "col-sm-6", tags$div(
          class = "card",
          tags$h3("Algorithm 1"),
          tags$ol(
            tags$li(HTML("Initialise \\(\\pi_k^{(old)},
                          \\boldsymbol{\\mu}_k^{(old)},
                          \\boldsymbol{\\Sigma}_k^{(old)}\\).")),
            tags$li(HTML("<b>Repeat:</b> E-step, then M-step.")),
            tags$li("Until the parameter estimates converge.")
          )
        ))
      ),
      tags$div(
        class = "card",
        tags$h3("M-step"),
        eqn("$$\\pi_k^{(new)} = \\frac{1}{n}\\sum_{i=1}^{n} p_{ik}^{(new)},
             \\qquad
             \\boldsymbol{\\mu}_k^{(new)} =
             \\frac{\\sum_{i=1}^{n} p_{ik}^{(new)} \\boldsymbol{x}_i}
                   {\\sum_{i=1}^{n} p_{ik}^{(new)}}$$"),
        eqn("$$\\boldsymbol{\\Sigma}_k^{(new)} =
             \\frac{\\sum_{i=1}^{n} p_{ik}^{(new)}
             \\left(\\boldsymbol{x}_i - \\boldsymbol{\\mu}_k^{(new)}\\right)
             \\left(\\boldsymbol{x}_i -
             \\boldsymbol{\\mu}_k^{(new)}\\right)^{\\top}}
             {\\sum_{i=1}^{n} p_{ik}^{(new)}}$$"),
        tags$div(class = "note",
                 HTML("<b>Key weakness.</b> Every observation contributes to
                       every update, so a single extreme point pulls the means
                       and inflates the covariances."))
      )
    )
  ),

  ## ---- Section 4 ------------------------------------------------------- ##
  tabPanel(
    "4. Self-Paced Learning",
    section_head(4, "Self-Paced Learning",
                 "Report Section 4, page 8; Algorithm 2 in the Appendix"),
    section_body(
      tags$div(
        class = "card",
        tags$h3("The objective"),
        eqn("$$E(\\boldsymbol{v}, \\boldsymbol{\\Theta} \\mid \\lambda) =
             \\sum_{i=1}^{n} v_i \\sum_{k=1}^{K} z_{ik}
             \\left[\\log \\pi_k + \\log N(\\boldsymbol{x}_i \\mid
             \\boldsymbol{\\mu}_k, \\boldsymbol{\\Sigma}_k)\\right]
             - \\lambda \\sum_{i=1}^{n} v_i$$"),
        tags$ul(
          tags$li(HTML("\\(v_i \\in \\{0,1\\}\\) indicates whether observation
                        \\(i\\) is included at the current iteration.")),
          tags$li(HTML("\\(\\lambda\\) is the <b>age parameter</b> controlling
                        how many observations are admitted.")),
          tags$li(HTML("\\(\\lambda \\sum_i v_i\\) is the self-paced
                        regulariser."))
        )
      ),
      tags$div(
        class = "row row-flex",
        tags$div(class = "col-sm-7", tags$div(
          class = "card",
          tags$h3("Selection rule"),
          eqn("$$v_i = \\begin{cases}
               1, & \\text{if } \\sum_{k=1}^{K} z_{ik}
               \\left[\\log \\pi_k + \\log N(\\boldsymbol{x}_i \\mid
               \\boldsymbol{\\mu}_k, \\boldsymbol{\\Sigma}_k)\\right]
               \\geq \\lambda \\\\[1ex]
               0, & \\text{otherwise.}
               \\end{cases}$$"),
          tags$p(HTML("The age parameter is then relaxed,
                       \\(\\lambda^{(new)} = \\lambda^{(old)} -
                       a\\lvert\\lambda^{(old)}\\rvert\\) with \\(a > 1\\),
                       admitting progressively less typical observations until
                       convergence."))
        )),
        tags$div(class = "col-sm-5", tags$div(
          class = "card",
          tags$h3("Updating equations"),
          tags$p(HTML("Identical to EM, except each term is weighted by
                       \\(v_i\\):")),
          eqn("$$\\boldsymbol{\\mu}_k^{(new)} =
               \\frac{\\sum_{i=1}^{n} v_i\\, p_{ik}^{(new)} \\boldsymbol{x}_i}
                     {\\sum_{i=1}^{n} v_i\\, p_{ik}^{(new)}}$$")
        ))
      ),
      tags$div(
        class = "card",
        tags$h3("From theory to implementation"),
        tags$div(class = "note",
                 HTML("The code trims by <i>rank</i> at a fixed proportion.
                       \\(\\lambda\\) is recovered afterwards as the highest
                       log-likelihood among the discarded points. The method
                       chooses <i>which</i> points to discard; the trimming
                       target sets <i>how many</i>."))
      )
    )
  ),

  ## ---- Section 5 ------------------------------------------------------- ##
  tabPanel(
    "5. Simulation Study",
    section_head(5, "Simulation Study", "Report Section 5, page 9"),
    section_body(
      sidebarLayout(
        sidebarPanel(
          width = 3,
          tags$h4("Simulation design"),
          helpText(HTML("Two-component bivariate GMM:<br>
                         \\(\\boldsymbol{\\pi}=(0.7,\\,0.3)\\)<br>
                         \\(\\boldsymbol{\\mu}_1=(-3,-3)\\),
                         \\(\\boldsymbol{\\mu}_2=(3,3)\\)<br>
                         \\(\\boldsymbol{\\Sigma}_k=\\boldsymbol{I}_2\\)")),
          tags$hr(),
          sliderInput("n", "Sample size n", 100, 2000, 500, step = 50),
          sliderInput("alpha", "Contamination level", 0, 0.4, 0.10, step = 0.01),
          sliderInput("trim_s", "SPL trimming target", 0, 0.4, 0.05, step = 0.01),
          numericInput("seed", "Seed", 2026, step = 1),
          helpText("Contaminating points are drawn Uniform(-10, 10) in each
                    coordinate and replace existing observations."),
          tags$hr(),
          actionButton("go_sim", "Fit both methods", class = "btn-primary")
        ),
        mainPanel(
          width = 9,
          tabsetPanel(
            tabPanel(
              "Live demonstration",
              br(),
              plotOutput("simplot", height = "420px"),
              verbatimTextOutput("simsumm")
            ),
            tabPanel(
              "Flagged observations",
              br(),
              helpText("Sorted by log-likelihood; the lowest are trimmed first."),
              verbatimTextOutput("simflag")
            ),
            tabPanel(
              "Table 1: Bias and MSE",
              br(),
              helpText(HTML("Based on \\(R = 500\\) replicates of size
                             \\(n = 500\\). \\(\\mu_{kj}\\) is the \\(j\\)th
                             coordinate of the mean of component \\(k\\).
                             The smaller value of each pair is shown in bold.")),
              tableOutput("simtable"),
              tags$div(class = "keypoint", tags$ul(
                tags$li(HTML("<b>0%</b> &mdash; the two methods are
                              indistinguishable. The self-paced penalty costs
                              nothing when it is not needed.")),
                tags$li(HTML("<b>5%</b> &mdash; SPL attains lower bias and MSE on
                              every parameter; EM develops a systematic negative
                              bias.")),
                tags$li(HTML("<b>10%</b> &mdash; EM breaks down, reaching a bias
                              of \\(-0.46\\) on \\(\\mu_{21}\\), while SPL stays
                              near its clean-data values."))
              ))
            )
          )
        )
      )
    )
  ),

  ## ---- Section 6 ------------------------------------------------------- ##
  tabPanel(
    "6. Old Faithful",
    section_head(6, "Application on Real Data", "Report Section 6, page 10"),
    section_body(
      sidebarLayout(
        sidebarPanel(
          width = 3,
          tags$h4("Data and fitting"),
          selectInput("ds", "Dataset",
                      c("Old Faithful" = "faithful",
                        "Iris" = "iris",
                        "Swiss banknotes" = "banknote")),
          uiOutput("varpick"),
          tags$hr(),
          sliderInput("K", "Number of components K", 1, 6, 2),
          sliderInput("trim_r", "SPL trimming target", 0, 0.4, 0.05, step = 0.01),
          numericInput("eig", "Eigenvalue-ratio cap", 20, min = 2),
          checkboxInput("std", "Standardise before fitting", TRUE),
          tags$hr(),
          actionButton("go_real", "Fit both methods", class = "btn-primary"),
          br(), br(),
          actionButton("bic", "Run BIC sweep, K = 1..6")
        ),
        mainPanel(
          width = 9,
          tabsetPanel(
            tabPanel(
              "Fitted models",
              br(),
              plotOutput("realplot", height = "420px"),
              verbatimTextOutput("realsumm")
            ),
            tabPanel(
              "Table 3: Parameters",
              br(),
              verbatimTextOutput("realparams")
            ),
            tabPanel(
              "Table 2: Model selection",
              br(),
              plotOutput("bicplot", height = "340px"),
              tableOutput("bictab"),
              tags$div(class = "note",
                       HTML("<b>Note on comparability.</b> The two BIC columns
                             are on different scales: EM uses the full
                             log-likelihood over all observations, SPL the
                             trimmed log-likelihood over the retained ones.
                             Compare K <i>within</i> a column, never
                             <i>across</i> columns."))
            ),
            tabPanel(
              "Flagged observations",
              br(),
              verbatimTextOutput("realflag")
            )
          )
        )
      )
    )
  ),

  ## ---- Section 7 ------------------------------------------------------- ##
  tabPanel(
    "7. Conclusion",
    section_head(7, "Discussion and Conclusion", "Report Section 8, page 12"),
    section_body(
      tags$div(
        class = "card",
        tags$h3("What was done"),
        tags$p("A two-component GMM was fitted by EM and by SPL in a Monte Carlo
                study of R = 500 replicates at three contamination levels, with
                accuracy measured by bias and MSE. Both methods were then applied
                to the Old Faithful data with K selected by BIC.")
      ),
      tags$div(
        class = "row row-flex",
        tags$div(class = "col-sm-6", tags$div(
          class = "card",
          tags$h3("Simulation findings"),
          tags$ul(
            tags$li("On uncontaminated data the two methods are
                     indistinguishable."),
            tags$li("Under contamination SPL attained lower bias and MSE on
                     every parameter at both the 5% and 10% levels."),
            tags$li("At 10% the EM estimates deteriorated substantially.")
          )
        )),
        tags$div(class = "col-sm-6", tags$div(
          class = "card",
          tags$h3("Real data findings"),
          tags$ul(
            tags$li("Both methods selected K = 2 and agreed closely on the means
                     and mixing proportions."),
            tags$li("SPL returned smaller variances and roughly halved
                     covariances after excluding the observations furthest into
                     the tails.")
          )
        ))
      ),
      tags$div(
        class = "card",
        tags$h3("Limitations and conclusion"),
        tags$ul(
          tags$li("A single simulation design: two components, bivariate, one
                   contamination mechanism, one trimming target."),
          tags$li("The number of flagged observations is set by the trimming
                   target, not discovered from the data."),
          tags$li("Generalisation to higher dimensions and overlapping
                   components remains open.")
        ),
        tags$div(class = "keypoint",
                 HTML("<b>Conclusion.</b> Self-paced learning is an effective and
                       readily implemented robust alternative to EM for Gaussian
                       mixture estimation."))
      )
    )
  ),

  ## ---- Acknowledgements ------------------------------------------------ ##
  tabPanel(
    "Acknowledgements",
    section_head(HTML("&#9733;"), "Acknowledgements", "Report page 4"),
    section_body(
      tags$div(
        class = "card",
        tags$p(HTML("With gratitude, I would like to acknowledge the financial
                     support of the <b>Nedbank Educational Trust</b>, without
                     which the degree would not have been possible.")),
        tags$p(HTML("I also want to thank my supervisor, <b>Mr Andre
                     Kleynhans</b>, for his continued guidance throughout this
                     research project and for his generosity in sharing his work
                     on self-paced learning for a finite mixture model, which
                     paved the way for me.")),
        tags$p("Finally, I would like to thank my family for their encouragement
                and support during this year."),
        
        tags$p(HTML("<b>This research was approved by the Ethics Committee, Faculty of Natural and Agricultural Sciences of the University of Pretoria, Reference Number NAS116/2019.</b>"))
        
      )
    )
  ),

  ## ---- References ------------------------------------------------------ ##
  tabPanel(
    "References",
    section_head(HTML("&#167;"), "References", "Report page 13"),
    section_body(
      tags$div(
        class = "card",
        tags$h3("Cited works"),
        tags$ol(
          style = "line-height:1.75;",
          tags$li(HTML("Rokach, L. and Maimon, O. (2005). Clustering methods.
                        In: O. Maimon and L. Rokach (eds.),
                        <i>Data Mining and Knowledge Discovery Handbook</i>,
                        pp. 321&ndash;352. Springer, Boston, MA.")),
          tags$li(HTML("Reynolds, D. (2009). Gaussian mixture models.
                        In: S. Z. Li and A. Jain (eds.),
                        <i>Encyclopedia of Biometrics</i>,
                        pp. 659&ndash;663. Springer, Boston, MA.")),
          tags$li(HTML("Kleynhans, A. R., Kanfer, F. H. J. and Millard, S. M.
                        (2026). Estimating finite mixture models using component
                        self-paced learning. In: M. Arashi and M. Norouzirad
                        (eds.), <i>Advances in Shrinkage and Penalized
                        Estimation Strategies</i>, Emerging Topics in Statistics
                        and Biostatistics, pp. 499&ndash;520. Springer Nature
                        Switzerland, Cham.")),
          tags$li(HTML("Zhang, Y., Tang, Q., Niu, L., Dai, T., Xiao, X. and
                        Xia, S.-T. (2018). Self-paced mixture of T distribution
                        model. In: <i>2018 IEEE International Conference on
                        Acoustics, Speech and Signal Processing (ICASSP)</i>,
                        pp. 2796&ndash;2800. IEEE.")),
          tags$li(HTML("Meng, D., Zhao, Q. and Jiang, L. (2017). A theoretical
                        understanding of self-paced learning.
                        <i>Information Sciences</i>, 414:319&ndash;328.")),
          tags$li(HTML("Kleynhans, A. R. (2022). <i>Robust parameter estimation
                        of finite mixture models with self-paced learning</i>.
                        MSc (eScience) mini-dissertation, University of Pretoria,
                        Pretoria.")),
          tags$li(HTML("Bishop, C. M. (2006). <i>Pattern Recognition and Machine
                        Learning</i>. Information Science and Statistics.
                        Springer, New York, NY.")),
          tags$li(HTML("Scrucca, L., Fop, M., Murphy, T. B. and Raftery, A. E.
                        (2016). mclust 5: Clustering, classification and density
                        estimation using Gaussian finite mixture models.
                        <i>The R Journal</i>, 8(1):289&ndash;317."))
        )
      ),
      tags$div(
        class = "card",
        tags$h3("Software"),
        tags$p(HTML("Analysis carried out in <b>R</b>. Mixture fitting by EM uses
                     the <code>mclust</code> package [8]; starting values use
                     trimmed k-means from <code>tclust</code>; this application
                     uses <code>shiny</code>."))
      )
    )
  ),

  ## ---- Appendix -------------------------------------------------------- ##
  tabPanel(
    "Appendix",
    section_head(HTML("&#43;"), "Appendix",
                 "Report page 14; algorithms and M-step derivations"),
    section_body(
      tags$div(
        class = "row row-flex",
        tags$div(class = "col-sm-6", tags$div(
          class = "card",
          tags$h3("Algorithm 1: EM"),
          tags$ol(
            tags$li(HTML("Initialise \\(\\pi_k^{(old)},
                          \\boldsymbol{\\mu}_k^{(old)},
                          \\boldsymbol{\\Sigma}_k^{(old)}\\) with random
                          values.")),
            tags$li(HTML("<b>Repeat</b><br>
                          &nbsp;&nbsp;&bull; E-step: compute
                          \\(p_{ik}^{(new)}\\)<br>
                          &nbsp;&nbsp;&bull; M-step: update
                          \\(\\pi_k^{(new)}, \\boldsymbol{\\mu}_k^{(new)},
                          \\boldsymbol{\\Sigma}_k^{(new)}\\)")),
            tags$li("Until the model parameters converge.")
          )
        )),
        tags$div(class = "col-sm-6", tags$div(
          class = "card",
          tags$h3("Algorithm 2: SPL"),
          tags$p(HTML("<b>Require:</b> \\(\\pi_k^{(old)},
                       \\boldsymbol{\\mu}_k^{(old)},
                       \\boldsymbol{\\Sigma}_k^{(old)},
                       \\lambda^{(old)}, a > 1\\)")),
          tags$ol(
            tags$li(HTML("<b>While</b> any \\(v_i^{(new)} = 0\\) or the estimates
                          have not converged:")),
            tags$li(HTML("Update the SPL weights \\(v_i^{(new)}\\).")),
            tags$li(HTML("<b>While</b> not converged: E-step, then update
                          \\(\\pi_k^{(new)}, \\boldsymbol{\\mu}_k^{(new)},
                          \\boldsymbol{\\Sigma}_k^{(new)}\\).")),
            tags$li(HTML("Relax the age parameter,
                          \\(\\lambda^{(new)} = \\lambda^{(old)} -
                          a\\lvert\\lambda^{(old)}\\rvert\\).")),
            tags$li("Carry the new values forward and repeat.")
          )
        ))
      ),
      tags$div(
        class = "card",
        tags$h3("A.1  Updating equation for \\(\\pi_k^{(new)}\\)"),
        tags$p(HTML("Maximise \\(Q_\\pi = \\sum_{i}\\sum_{k} p_{ik}^{(new)}
                     \\log \\pi_k\\) subject to \\(\\sum_k \\pi_k = 1\\). The
                     Lagrangian is")),
        eqn("$$\\mathcal{L}(\\pi_1,\\dots,\\pi_K,\\gamma) =
             \\sum_{k=1}^{K}\\sum_{i=1}^{n} p_{ik}^{(new)}\\log \\pi_k
             + \\gamma\\left(\\sum_{k=1}^{K}\\pi_k - 1\\right).$$"),
        tags$p(HTML("Setting \\(\\partial\\mathcal{L}/\\partial\\pi_k = 0\\)
                     gives \\(\\pi_k = -\\gamma^{-1}\\sum_i p_{ik}^{(new)}\\).
                     Since \\(\\sum_k \\pi_k = 1\\) and
                     \\(\\sum_k p_{ik}^{(new)} = 1\\), we get \\(\\gamma = -n\\)
                     and therefore")),
        eqn("$$\\pi_k^{(new)} = \\frac{1}{n}\\sum_{i=1}^{n} p_{ik}^{(new)}.$$")
      ),
      tags$div(
        class = "card",
        tags$h3("A.2  Updating equation for
                 \\(\\boldsymbol{\\mu}_k^{(new)}\\)"),
        eqn("$$Q_{\\boldsymbol{\\mu}_k} = -\\tfrac{1}{2}\\sum_{i=1}^{n}
             p_{ik}^{(new)}(\\boldsymbol{x}_i - \\boldsymbol{\\mu}_k)^{\\top}
             \\boldsymbol{\\Sigma}_k^{-1}
             (\\boldsymbol{x}_i - \\boldsymbol{\\mu}_k)$$"),
        tags$p(HTML("Using \\(\\partial/\\partial\\boldsymbol{\\mu}\\,
                     [(\\boldsymbol{x}-\\boldsymbol{\\mu})^{\\top}
                     \\boldsymbol{\\Sigma}^{-1}
                     (\\boldsymbol{x}-\\boldsymbol{\\mu})]
                     = -2\\boldsymbol{\\Sigma}^{-1}
                     (\\boldsymbol{x}-\\boldsymbol{\\mu})\\) and setting the
                     derivative to \\(\\boldsymbol{0}\\),")),
        eqn("$$\\boldsymbol{\\mu}_k^{(new)} =
             \\frac{\\sum_{i=1}^{n} p_{ik}^{(new)}\\boldsymbol{x}_i}
                   {\\sum_{i=1}^{n} p_{ik}^{(new)}}.$$")
      ),
      tags$div(
        class = "card",
        tags$h3("A.3  Updating equation for
                 \\(\\boldsymbol{\\Sigma}_k^{(new)}\\)"),
        eqn("$$Q_{\\boldsymbol{\\Sigma}_k} = -\\tfrac{1}{2}\\sum_{i=1}^{n}
             p_{ik}^{(new)}\\left[\\log|\\boldsymbol{\\Sigma}_k| +
             (\\boldsymbol{x}_i-\\boldsymbol{\\mu}_k)^{\\top}
             \\boldsymbol{\\Sigma}_k^{-1}
             (\\boldsymbol{x}_i-\\boldsymbol{\\mu}_k)\\right]$$"),
        tags$p(HTML("Using the trace identity
                     \\((\\boldsymbol{x}_i-\\boldsymbol{\\mu}_k)^{\\top}
                     \\boldsymbol{\\Sigma}_k^{-1}
                     (\\boldsymbol{x}_i-\\boldsymbol{\\mu}_k)
                     = \\operatorname{tr}(\\boldsymbol{\\Sigma}_k^{-1}
                     (\\boldsymbol{x}_i-\\boldsymbol{\\mu}_k)
                     (\\boldsymbol{x}_i-\\boldsymbol{\\mu}_k)^{\\top})\\)
                     together with
                     \\(\\partial\\log|\\boldsymbol{\\Sigma}|/
                     \\partial\\boldsymbol{\\Sigma}
                     = \\boldsymbol{\\Sigma}^{-1}\\) and
                     \\(\\partial\\operatorname{tr}(\\boldsymbol{\\Sigma}^{-1}
                     \\boldsymbol{A})/\\partial\\boldsymbol{\\Sigma}
                     = -\\boldsymbol{\\Sigma}^{-1}\\boldsymbol{A}
                     \\boldsymbol{\\Sigma}^{-1}\\), and solving,")),
        eqn("$$\\boldsymbol{\\Sigma}_k^{(new)} =
             \\frac{\\sum_{i=1}^{n} p_{ik}^{(new)}
             \\left(\\boldsymbol{x}_i-\\boldsymbol{\\mu}_k^{(new)}\\right)
             \\left(\\boldsymbol{x}_i-
             \\boldsymbol{\\mu}_k^{(new)}\\right)^{\\top}}
             {\\sum_{i=1}^{n} p_{ik}^{(new)}}.$$"),
        tags$div(class = "note",
                 HTML("For SPL every sum above is weighted by \\(v_i\\), so the
                       trimmed observations contribute nothing to any update."))
      )
    )
  )
)

################################################################################
#  Server                                                                      #
################################################################################

server <- function(input, output, session) {

  ensure_mclust()

  ## ======================= Section 5: simulation ======================== ##

  sim_fits <- eventReactive(input$go_sim, {
    s <- rGMM(n = input$n,
              pie = c(0.7, 0.3),
              mu = matrix(c(-3, -3, 3, 3), 2, byrow = TRUE),
              Sigma = array(c(diag(2), diag(2)), c(2, 2, 2)),
              alpha = input$alpha, bounds = c(-10, 10),
              seed = input$seed)
    X <- s$X

    withProgress(message = "Fitting", value = 0.2, {
      init <- init_tkmeans(X, 2, seed = 2026L,
                           trim = max(input$trim_s, 0.02), nstart = 50)
      incProgress(0.4)
      em <- fit_em_K(X, init, 2)
      incProgress(0.2)
      spl <- gmm_em_spl(X, init$pie, init$mu, init$Sigma,
                        prop_cut = min(input$trim_s + 0.20, 0.5),
                        target_cut = input$trim_s,
                        cut_decay = 0.05, eig_ratio = 20,
                        max_outer = 300, max_inner = 100, tol = 1e-6)
      incProgress(0.2)
    })

    list(em = em, spl = spl, X = X, contam = s$contam_idx, trim = input$trim_s)
  })

  output$simplot <- renderPlot({
    f <- sim_fits(); n <- nrow(f$X)
    em_lab <- max.col(estep_log(f$X, f$em$pie, f$em$mu, f$em$Sigma)$r,
                      ties.method = "first")
    em_fit <- list(mu = matrix(f$em$mu, 2, 2),
                   Sigma = array(f$em$Sigma, c(2, 2, 2)),
                   labels = em_lab, V = rep(1L, n))
    spl_fit <- list(mu = matrix(f$spl$mu, 2, 2),
                    Sigma = array(f$spl$Sigma, c(2, 2, 2)),
                    labels = f$spl$labels, V = f$spl$V)
    op <- par(mfrow = c(1, 2), bg = "white"); on.exit(par(op))
    plt_gmm(f$X, em_fit, 0.95, main = "EM")
    plt_gmm(f$X, spl_fit, 0.95,
            main = sprintf("SPL, trim = %.0f%%", 100 * f$trim))
  })

  output$simsumm <- renderPrint({
    f <- sim_fits(); n <- nrow(f$X); n_flag <- sum(f$spl$V == 0L)
    cat(sprintf("n = %d | contamination = %.0f%% | trimming target = %.0f%%\n",
                n, 100 * length(f$contam) / n, 100 * f$trim))
    cat(sprintf("SPL flagged %d observations (%.1f%%), lambda = %.3f\n",
                n_flag, 100 * n_flag / n, f$spl$lambda))
    cat("\nTrue means: component 1 = (-3, -3), component 2 = (3, 3)\n")
    cat("EM  estimated means:\n");  print(round(matrix(f$em$mu, 2, 2), 3))
    cat("SPL estimated means:\n"); print(round(matrix(f$spl$mu, 2, 2), 3))
    cat(sprintf("\nMixing proportions  EM: %.3f, %.3f | SPL: %.3f, %.3f\n",
                f$em$pie[1], f$em$pie[2], f$spl$pie[1], f$spl$pie[2]))
    if (length(f$contam)) {
      ev <- eval_fit(list(X = f$X, contam_idx = f$contam), f$spl)
      cat(sprintf("\nOutlier detection (true contamination known):\n"))
      cat(sprintf("  truly contaminated %d | flagged %d | TP %d, FP %d, FN %d\n",
                  length(f$contam), n_flag, ev$TP, ev$FP, ev$FN))
      cat(sprintf("  precision %.3f | recall %.3f | F1 %.3f\n",
                  ev$precision, ev$recall, ev$f1))
    }
    if (f$trim == 0)
      cat("\nTrimming is zero: SPL reduces exactly to the classical EM algorithm.\n")
  })

  output$simflag <- renderPrint({
    f <- sim_fits(); idx <- which(f$spl$V == 0L)
    if (!length(idx)) { cat("No observations flagged.\n"); return(invisible()) }
    out <- data.frame(obs = idx, round(f$X[idx, , drop = FALSE], 3),
                      loglik = round(f$spl$ell[idx], 3))
    if (length(f$contam)) out$truly_contaminated <- idx %in% f$contam
    print(out[order(out$loglik), ], row.names = FALSE)
  })

  output$simtable <- renderTable({
    bold <- function(a, b, col) {
      ifelse(abs(a) <= abs(b),
             sprintf("<b style='color:%s'>%.4f</b>", col, a),
             sprintf("%.4f", a))
    }
    data.frame(
      Contamination = sim_table$Contamination,
      Parameter = sim_table$Parameter,
      `Bias SPL` = bold(sim_table$Bias_SPL, sim_table$Bias_EM, COL_SPL),
      `Bias EM`  = bold(sim_table$Bias_EM, sim_table$Bias_SPL, COL_EM),
      `MSE SPL`  = bold(sim_table$MSE_SPL, sim_table$MSE_EM, COL_SPL),
      `MSE EM`   = bold(sim_table$MSE_EM, sim_table$MSE_SPL, COL_EM),
      check.names = FALSE
    )
  }, sanitize.text.function = identity, striped = TRUE, bordered = TRUE)

  ## ====================== Section 6: real data ========================== ##

  raw_real <- reactive({
    switch(input$ds,
           faithful = faithful,
           iris     = iris[, 1:4],
           banknote = { data(banknote, package = "mclust"); banknote[, -1] })
  })

  output$varpick <- renderUI({
    nm <- names(raw_real())
    if (length(nm) <= 2) return(NULL)
    tagList(
      selectInput("v1", "Horizontal variable", nm, selected = nm[1]),
      selectInput("v2", "Vertical variable",   nm, selected = nm[2])
    )
  })

  dat_real <- reactive({
    df <- raw_real(); nm <- names(df)
    cols <- if (length(nm) <= 2) nm[1:2]
            else c(input$v1 %||% nm[1], input$v2 %||% nm[2])
    validate(need(cols[1] != cols[2], "Pick two different variables."))
    list(X = as.matrix(df[, cols, drop = FALSE]), names = cols)
  })

  fit_both_real <- function(K) {
    d <- dat_real(); X_raw <- d$X
    centre <- if (input$std) colMeans(X_raw) else rep(0, 2)
    scl    <- if (input$std) apply(X_raw, 2, sd) else rep(1, 2)
    X <- scale(X_raw, center = centre, scale = scl)
    init <- init_tkmeans(X, K, seed = 2026L,
                         trim = max(input$trim_r, 0.02), nstart = 50)
    em <- fit_em_K(X, init, K)
    spl <- gmm_em_spl(X, init$pie, init$mu, init$Sigma,
                      prop_cut = min(input$trim_r + 0.20, 0.5),
                      target_cut = input$trim_r, cut_decay = 0.05,
                      eig_ratio = input$eig,
                      max_outer = 300, max_inner = 100, tol = 1e-6)
    list(em = em, spl = spl, X = X, X_raw = X_raw, centre = centre,
         scl = scl, names = d$names, K = K)
  }

  real_fits <- eventReactive(input$go_real, {
    withProgress(message = "Fitting", value = 0.5, fit_both_real(input$K))
  })

  output$realplot <- renderPlot({
    f <- real_fits(); n <- nrow(f$X_raw)
    em_lab <- max.col(estep_log(f$X, f$em$pie, f$em$mu, f$em$Sigma)$r,
                      ties.method = "first")
    em_fit <- list(mu = unscale_mu(matrix(f$em$mu, f$K, 2), f$centre, f$scl),
                   Sigma = unscale_Sigma(array(f$em$Sigma, c(2, 2, f$K)), f$scl),
                   labels = em_lab, V = rep(1L, n))
    spl_fit <- list(mu = unscale_mu(matrix(f$spl$mu, f$K, 2), f$centre, f$scl),
                    Sigma = unscale_Sigma(array(f$spl$Sigma, c(2, 2, f$K)), f$scl),
                    labels = f$spl$labels, V = f$spl$V)
    op <- par(mfrow = c(1, 2), bg = "white"); on.exit(par(op))
    plt_gmm(f$X_raw, em_fit, 0.95, main = sprintf("EM, K = %d", f$K))
    plt_gmm(f$X_raw, spl_fit, 0.95,
            main = sprintf("SPL, K = %d, trim = %.0f%%", f$K, 100 * input$trim_r))
  })

  output$realsumm <- renderPrint({
    f <- real_fits(); n <- nrow(f$X_raw); n_flag <- sum(f$spl$V == 0L)
    cat(sprintf("n = %d | variables: %s, %s | K = %d\n",
                n, f$names[1], f$names[2], f$K))
    cat(sprintf("SPL flagged %d observations = floor(%.2f x %d), lambda = %.3f\n",
                n_flag, input$trim_r, n, f$spl$lambda))
    cat(sprintf("Log-likelihood: EM %.2f (all %d points) | SPL %.2f (%d retained)\n",
                f$em$loglik, n, f$spl$loglik, sum(f$spl$V == 1L)))
    cat("\nThe flagged count is fixed by the trimming target, not discovered\n")
    cat("from the data. SPL chooses WHICH points to discard, not HOW MANY.\n")
  })

  output$realparams <- renderPrint({
    f <- real_fits()
    for (m in c("em", "spl")) {
      fit <- f[[m]]
      cat(sprintf("\n---- %s ----\n", toupper(m)))
      cat("Mixing proportions:\n"); print(round(fit$pie, 4))
      mu <- unscale_mu(matrix(fit$mu, f$K, 2), f$centre, f$scl)
      dimnames(mu) <- list(paste("component", seq_len(f$K)), f$names)
      cat("Component means:\n"); print(round(mu, 3))
      Sg <- unscale_Sigma(array(fit$Sigma, c(2, 2, f$K)), f$scl)
      cat("Component variances and covariances:\n")
      for (k in seq_len(f$K)) {
        S <- Sg[, , k]; dimnames(S) <- list(f$names, f$names)
        cat(sprintf(" component %d:\n", k)); print(round(S, 3))
      }
    }
  })

  output$realflag <- renderPrint({
    f <- real_fits(); idx <- which(f$spl$V == 0L)
    if (!length(idx)) { cat("No observations flagged.\n"); return(invisible()) }
    out <- data.frame(obs = idx, f$X_raw[idx, , drop = FALSE],
                      loglik = round(f$spl$ell[idx], 3))
    print(out[order(out$loglik), ], row.names = FALSE)
  })

  sweep <- eventReactive(input$bic, {
    n <- nrow(dat_real()$X)
    withProgress(message = "BIC sweep", value = 0, {
      rows <- lapply(1:6, function(k) {
        incProgress(1 / 6, detail = paste("K =", k))
        f <- fit_both_real(k)
        np <- npar_VVV(k, 2); nk <- sum(f$spl$V == 1L)
        data.frame(K = k, npar = np,
                   loglik_EM = f$em$loglik,
                   BIC_EM = if (is.finite(f$em$loglik))
                     bic_from(f$em$loglik, np, n) else NA,
                   loglik_SPL = f$spl$loglik,
                   BIC_SPL = bic_from(f$spl$loglik, np, nk),
                   flagged = n - nk)
      })
    })
    do.call(rbind, rows)
  })

  output$bictab <- renderTable(sweep(), digits = 2, striped = TRUE,
                               bordered = TRUE)

  output$bicplot <- renderPlot({
    tb <- sweep()
    op <- par(mfrow = c(1, 2), bg = "white"); on.exit(par(op))
    plot(tb$K, tb$BIC_EM, type = "b", pch = 16, col = COL_EM, lwd = 2,
         xlab = "K", ylab = "BIC", main = "EM (full likelihood)")
    abline(v = tb$K[which.min(tb$BIC_EM)], lty = 3, col = COL_EM)
    plot(tb$K, tb$BIC_SPL, type = "b", pch = 15, col = COL_SPL, lwd = 2,
         xlab = "K", ylab = "BIC", main = "SPL (trimmed likelihood)")
    abline(v = tb$K[which.min(tb$BIC_SPL)], lty = 3, col = COL_SPL)
  })
}

shinyApp(ui, server)
