################################################################################
# Robust Gaussian mixture fitting the EM with SPL
#
#  LAYOUT
#    1. Numerical helpers        (incl. the eigenvalue-ratio constraint)
#    2. Data generation (rGMM)
#    3. Main routine (gmm_em_spl)
#    4. Plotting
#    5. Evaluation
#    6. CONFIGURATION            <- the only place you edit design constants
#    7. Study helpers            (initialise / simulate / fit / score / save)
#    8. Export                   (per-replicate files, stacked sheet, or both)
#    9. Demonstration            (one dataset)
#   10. Monte Carlo run          (R replicates at CFG$alpha)
#   11. Contamination sweep      (all replicates at several alpha levels)
#   12. TWO-METHOD COMPARISON    (classical EM via mclust vs SPL-EM)
#   13. DIAGNOSTICS              (does the fit actually find the clusters?)
#   14. MEAN-ESTIMATE STORE      -> BIAS and MSE per scenario
#   15. EXECUTION               
#
# Section 1-5 are the machinery and never mention a design constant
# Section 6-14 are the study and read everything from cfg object.
# 
# Design:
#
#    Generating:  CFG$pie / CFG$mu / CFG$Sigma are the TRUE parameters. They
#                 draw the data and, at the end, serve as the target the
#                 estimates are scored against. No estimator sees them.
#    Fitting:     one trimmed-kmeans start per replicate, computed from that
#                 replicate's own X and shared by mclust EM and SPL-EM, so
#                 any difference in the estimates is attributable to the
#                 trimming and not to the start point.
#
# Requirements (packages to install)
#    mclust   which is classical for EM
#    openxlsx or writexl for the excel output


################################################################################
#   1. Numerical helpers 
################################################################################
#
# Log density of a multivariate normal evaluate at every row of X
# Uses the Cholesky factor:  Sigma = t(R) %*$ R
log_dmvn <- function(X, mu, Sigma) {
  X <- as.matrix(X)                                                             #force X to matrix form
  d <- ncol(X)                                                                  #getting number of columns
  R <- tryCatch(chol(Sigma), error = function(e) chol(Sigma + diag(1e-6, d)))   #Cholesky factor
  Xc <- sweep(X, 2, as.numeric(mu), "-")                                        #Centers the rows
  z  <- backsolve(R, t(Xc), transpose = TRUE)                                   # solve t(R) %*% z = t(Xc); z is d x n, the "whitened" residuals
  quad   <- colSums(z * z)                                                      #squared Mahalanobis distance per observation
  logdet <- 2 * sum(log(diag(R)))                                               # log|Sigma| = 2 * sum(log(diagonal of R));
  -0.5 * (d * log(2 * pi) + logdet + quad)                                      # the MVN log density formula
}

# The full E step in log space
# Returns responsibilities r (n x K) and per observation log-likelihood ell
estep_log <- function(X, pie_k, mu, Sigma) {
  n <- nrow(X); K <- length(pie_k)                                              # n observations, K mixture components
  lw <- matrix(0, n, K)                                                         # will hold log(pi_k) + log N(x_i | mu_k, Sigma_k)
  for (k in 1:K) {
    lw[, k] <- log(pie_k[k] + 1e-300) +                                         # log of the mixing weight
      log_dmvn(X, mu[k, ], matrix(Sigma[, , k], ncol(X), ncol(X)))              # log density of component k at every point
  }
  mx  <- apply(lw, 1, max)                                                      #the log-sum-exp shift constant
  ell <- mx + log(rowSums(exp(lw - mx)))                                        # log-sum-exp -> per-observation log-likelihood log p(x_i)
  r   <- exp(lw - ell)                                                          #Responsibilities
  list(r = r, ell = ell)
}

# This exact the rank-based trimming: flag the cut lowest likelihood points
# Return V( 1= keep ) and the implied lambda for reporting.
V_from_prop <- function(ell, cut) {
  n <- length(ell)                                                              # number of observations
  m <- floor(cut * n)                                                           # how many points to flag as contamination
  m <- max(0L, min(as.integer(m), n))                                           # clamp into [0, n] so a bad `cut` can't break things
  V <- rep(1L, n)                                                               # start with everything kept (1 = keep)
  if (m > 0L) {
    drop_idx <- order(ell, decreasing = FALSE)[seq_len(m)]                      # indices of the m smallest log-likelihoods
    V[drop_idx] <- 0L                                                           # mark those as flagged (0 = discard)
  }
  lambda <- if (m == 0L) -Inf else max(ell[V == 0L])                            #highest ell among discarded points
  list(V = V, lambda = lambda)
  
}

#### ---- eigenvalue-ratio constraint -------------------------------------------
# The mixture likelihood is unbounded: one component can spread out to blanket
# the noise, or collapse onto a handful of points, and both raise the
# likelihood without describing anything. This caps the ratio of largest to
# smallest eigenvalue ACROSS all components, the standard TCLUST-style
# restriction that makes the problem well posed.
#
# The clamp is anchored on the GEOMETRIC MEAN eigenvalue rather than on the
# smallest one: anchoring on the smallest would let a single collapsed
# component drag every other component down with it.
#
# ratio = Inf disables the constraint entirely.
################################################################################

constrain_sigma <- function(Sigma, ratio = Inf) {
  
  if (!is.finite(ratio) || ratio <= 1) return(Sigma)                            # disabled
  d <- dim(Sigma)[1]; K <- dim(Sigma)[3]
  if (anyNA(Sigma)) return(Sigma)
  
  eigs <- lapply(seq_len(K), function(k)
    eigen(0.5 * (Sigma[, , k] + t(Sigma[, , k])), symmetric = TRUE))            # symmetrise first, guard against drift
  
  all_val <- unlist(lapply(eigs, function(e) e$values))
  all_val <- all_val[is.finite(all_val) & all_val > 0]
  if (!length(all_val)) return(Sigma)
  
  g  <- exp(mean(log(all_val)))                                                 # typical scale, robust to one wild component
  lo <- g / sqrt(ratio)                                                         # so hi / lo == ratio exactly
  hi <- g * sqrt(ratio)
  
  for (k in seq_len(K)) {
    v <- pmin(pmax(eigs[[k]]$values, lo), hi)                                   # clamp every eigenvalue into [lo, hi]
    Sigma[, , k] <- eigs[[k]]$vectors %*% diag(v, d, d) %*% t(eigs[[k]]$vectors)
  }
  Sigma
}

################################################################################
##  2. DATA GENERATION
################################################################################
# n:      number of points
# pie:    mixing weights (length K, normalised internally)
# mu:     component means (K x d)
# Sigma:  covariances (d x d x K)
# alpha:  contamination fraction in [0, 1]
# bounds: range of the uniform noise
################################################################################

rGMM <- function(n, pie, mu, Sigma, alpha = 0, bounds = c(-10, 10), seed = NULL) {
  
  if (!is.null(seed)) set.seed(seed)                                            # fix the RNG for reproducibility if a seed is given
  pie <- as.numeric(pie); pie <- pie / sum(pie)                                 # Coerce and normalise mixing weights to sum to 1
  mu  <- as.matrix(mu)                                                          # K x d matrix of component means
  K   <- length(pie)                                                            # Number of components
  d   <- ncol(mu)                                                               # Dimensionality
  Sigma <- array(Sigma, dim = c(d, d, K))                                       # Coerce covariances into a d x d x K array
  
  labels <- sample.int(K, size = n, replace = TRUE, prob = pie)
  
  chols <- lapply(1:K, function(k) chol(matrix(Sigma[, , k], d, d) + diag(1e-8, d)))
  
  X <- matrix(NA_real_, n, d)                                                   #Pre allocate the data matrix
  for (k in 1:K) {
    idx <- which(labels == k)                                                   #rows assigned to component k
    if (!length(idx)) next
    Z <- matrix(rnorm(length(idx) * d), nrow = length(idx), ncol = d)           # iid standard normals
    X[idx, ] <- sweep(Z %*% chols[[k]], 2, mu[k, ], "+")                        # Z %*% R has covariance t(R)R = Sigma;
  }
  
  m <- floor(alpha * n)                                                         #number of points to contaminate
  contam_idx <- integer(0)                                                      #default is none
  if (m > 0) {
    contam_idx <- sample.int(n, m)                                              #choose which rows get replaced
    X[contam_idx, ] <- matrix(runif(m * d, bounds[1], bounds[2]), nrow = m, ncol = d)
    labels[contam_idx] <- 0L                                                    #label 0 marks contamination, used later for scoring
  }
  
  list(X = X, labels = labels, contam_idx = contam_idx)
}

################################################################################
#    3. Main routine: SPL-EM
################################################################################
# X            data matrix (n x d)
# pie, mu, Sigma   initial values
# prop_cut     STARTING trimming proportion (conservative: trim a lot early)
# target_cut   FINAL trimming proportion (set near the expected contamination)
# cut_decay    geometric rate at which prop_cut anneals toward target_cut
# eig_ratio    cap on the eigenvalue ratio across components; Inf = off
# max_outer / max_inner / tol   loop controls
#
# cut_t = target + (prop_cut - target) * (1 - cut_decay)^(t-1)
# so the trimming level converges to target_cut instead of drifting to zero.
# The schedule only does useful work when prop_cut > target_cut: trim hard
# while the parameters are still poor, relax as they improve.
################################################################################

gmm_em_spl <- function(X, pie, mu, Sigma,
                       prop_cut   = 0.5,
                       target_cut = NULL,
                       cut_decay  = 0.05,
                       eig_ratio  = Inf,
                       max_outer  = 300,                                        #enough for the annealing schedule to arrive
                       max_inner  = 100,
                       tol        = 1e-6,
                       verbose    = FALSE) {
  
  ## ---- set-up ----------------------------------------------------------
  if (is.null(dim(X))) X <- matrix(X, ncol = 1)                                 #treat a bare vector as univariate data
  X <- as.matrix(X)
  n <- nrow(X); d <- ncol(X); K <- length(pie)                                  #sample size, dimension, number of components
  
  pie_k <- as.numeric(pie); pie_k <- pie_k / sum(pie_k)                         #copy of mixing weights, normalised
  mu    <- as.matrix(mu)                                                        #copy of the means
  Sigma <- array(Sigma, dim = c(d, d, K))                                       #copy of the covariances
  Sigma <- constrain_sigma(Sigma, eig_ratio)                                    #a wild starting covariance cannot dominate iteration 1
  
  if (is.null(target_cut)) target_cut <- prop_cut                               # no annealing by default
  
  # never trim so hard that a component cannot be estimated
  cut_ceiling <- 1 - (K * (d + 1) + 1) / n                                      #keep at least enough points to identify K means + K variances
  prop_cut    <- min(max(prop_cut,   0), cut_ceiling)
  target_cut  <- min(max(target_cut, 0), cut_ceiling)
  
  snap_tol <- 0.5 / n
  
  ## ---- state -----------------------------------------------------------
  V_prev    <- rep(1L, n)                                                       #From previous iteration, checking for stability
  ll_prev   <- -Inf                                                             #trimmed log-likelihood from outer iteration
  lambda    <- -Inf                                                             #current implied threshold
  hist_cut  <- numeric(0)                                                       #trace of the trimming level per outer iteration
  hist_ll   <- numeric(0)                                                       #trace of the trimmed log likelihood per outer iteration
  it_inner  <- 0L                                                               #initialised so it exists even if a loop never runs
  converged <- FALSE                                                            #set TRUE if the outer loop breaks on the convergence test
  
  ## ---- OUTER LOOP: update the SPL weights V ----------------------------
  for (it_outer in 1:max_outer) {
    
    cut_t <- target_cut + (prop_cut - target_cut) * (1 - cut_decay)^(it_outer - 1)
    if (abs(cut_t - target_cut) < snap_tol) cut_t <- target_cut                 # snap once the trim COUNT can no longer differ
    
    E   <- estep_log(X, pie_k, mu, Sigma)                                       # Responsibilities and per point log likelihood
    trm <- V_from_prop(E$ell, cut_t)                                            # trim the worst cut_t proportion by log-likelihood
    V      <- trm$V                                                             # binary keep/discard indicator
    lambda <- trm$lambda                                                        # the threshold this trimming implies
    
    min_keep <- K * (d + 1) + 1                                                 
    if (sum(V) < min_keep) {                                                   
      keep <- order(E$ell, decreasing = TRUE)[seq_len(min_keep)]                
      V <- as.integer(seq_len(n) %in% keep)                                     
    }
    
    ## ---- INNER LOOP: EM with V fixed ----------------------------------
    ll_in_prev <- -Inf
    for (it_inner in 1:max_inner) {
      
      # E-step (at current params) -> likelihood -> convergence -> M-step,
      # so the likelihood always matches the parameters it is reported for
      E  <- estep_log(X, pie_k, mu, Sigma)                                      #responsibilities at the current parameters
      ll <- sum(E$ell[V == 1L])                                                 # trimmed log-likelihood
      
      if (is.finite(ll_in_prev) &&
          abs(ll - ll_in_prev) < tol * (abs(ll_in_prev) + 1)) break             #Relative tolerance
      ll_in_prev <- ll                                                          #store for the next comparison
      
      # --- M-step, responsibilities masked by the SPL weights
      w  <- E$r * V                                                             #V recycled column wise; flagged rows get weight 0 in every component
      Nk <- colSums(w)                                                          # effective number of kept points assigned to each component
      
      pie_k <- (Nk + 1e-12) / sum(Nk + 1e-12)                                   #updating the mixing weights
      
      for (k in 1:K) {
        if (Nk[k] <= 1e-8) next                                                 # leave an empty component alone
        mu[k, ] <- colSums(w[, k] * X) / Nk[k]                                  # weighted mean: sum_i w_ik x_i / sum_i w_ik
        Xc <- sweep(X, 2, mu[k, ], "-")                                         #center on the updated mean
        Sigma[, , k] <- crossprod(Xc, w[, k] * Xc) / Nk[k] + diag(1e-6, d)      #diag(1e-6, d) is a ridge that stops Sigma going singular
      }
      
      Sigma <- constrain_sigma(Sigma, eig_ratio)                                #no component may blanket the noise or collapse to a point
    }
    
    hist_cut <- c(hist_cut, cut_t)                                              #record the trimming level
    hist_ll  <- c(hist_ll,  ll)                                                 #record the resulting trimmed log likelihood
    
    if (verbose) {
      cat(sprintf("outer %3d | cut = %.3f | kept = %4d | lambda = %8.3f | ll = %12.3f\n",
                  it_outer, cut_t, sum(V), lambda, ll))                         # one diagnostic line per outer iteration
    }
    
    schedule_done <- abs(cut_t - target_cut) < snap_tol                         # outer convergence test
    if (schedule_done && identical(V, V_prev) &&                                #flagged set stops changing
        is.finite(ll_prev) && abs(ll - ll_prev) < tol * (abs(ll_prev) + 1)) {   #likelihood stable
      converged <- TRUE
      break
    }
    V_prev  <- V
    ll_prev <- ll
  }
  
  ## ---- final E-step so labels / responsibilities match final params ----
  E      <- estep_log(X, pie_k, mu, Sigma)                                      #recompute at the converged parameters
  trm    <- V_from_prop(E$ell, target_cut)                                      #final trimming at the target level
  V      <- trm$V
  lambda <- trm$lambda
  ll     <- sum(E$ell[V == 1L])                                                 #final trimmed log likelihood
  
  labels <- apply(E$r, 1, which.max)                                            #hard assignment (each point to its most probable component)
  labels[V == 0L] <- 0L
  
  list(pie              = pie_k,                                                #estimated mixing weights
       mu               = mu,                                                   #estimated means
       Sigma            = Sigma,                                                #estimated covariances
       responsibilities = E$r,                                                  #soft assignments
       ell              = E$ell,                                                # per-observation log-likelihoods
       labels           = labels,                                               #hard labels
       V                = V,                                                    # 1 = kept, 0 = flagged as contamination
       lambda           = lambda,                                               # implied threshold at the final trim level
       loglik           = ll,                                                   # TRIMMED log-lik at the returned params
       converged        = converged,                                            # outer loop met the convergence test
       eig_ratio        = eig_ratio,
       history          = list(cut = hist_cut, loglik = hist_ll),               #trace for plotting
       iters            = list(outer = it_outer, inner = it_inner))
}


################################################################################
##  4. PLOTTING
################################################################################

plt_gmm <- function(X, fit, level = 0.95, V = NULL, legend_pos = "topright",
                    main = NULL) {
  
  X <- as.matrix(X)
  stopifnot(ncol(X) == 2)
  K <- nrow(fit$mu)
  
  if (is.null(V)) V <- if (!is.null(fit$V)) fit$V else rep(1L, nrow(X))
  V <- as.integer(V > 0)
  stopifnot(length(V) == nrow(X))
  
  labels <- if (!is.null(fit$labels)) fit$labels else rep(1L, nrow(X))
  
  base_cols <- c("red3", "deeppink", "darkorange", "purple3", "navy", "firebrick3")
  comp_cols <- base_cols[(seq_len(K) - 1) %% length(base_cols) + 1]
  
  pt_cols <- rep(NA_character_, length(labels))
  for (k in 1:K) pt_cols[labels == k] <- comp_cols[k]
  pt_cols[labels == 0] <- "forestgreen"
  
  rx <- range(X[, 1]); ry <- range(X[, 2])
  padx <- 0.1 * diff(rx); pady <- 0.1 * diff(ry)
  
  plot(X, pch = 16, cex = 0.6, col = pt_cols,
       xlim = c(rx[1] - padx, rx[2] + padx),
       ylim = c(ry[1] - pady, ry[2] + pady),
       xlab = "X1", ylab = "X2",
       main = if (is.null(main))
         sprintf("SPL-EM GMM (%.0f%% ellipses; V == 0 marked)", 100 * level) else main)
  
  c2   <- qchisq(level, df = 2)
  th   <- seq(0, 2 * pi, length.out = 200)
  unit <- rbind(cos(th), sin(th))
  
  for (k in 1:K) {
    S  <- 0.5 * (fit$Sigma[, , k] + t(fit$Sigma[, , k]))
    eg <- eigen(S, symmetric = TRUE)
    A  <- eg$vectors %*% diag(sqrt(pmax(eg$values, 0) * c2), 2, 2)
    E  <- t(A %*% unit)
    lines(E[, 1] + fit$mu[k, 1], E[, 2] + fit$mu[k, 2],
          lty = 2, lwd = 1.4, col = comp_cols[k])
  }
  
  points(fit$mu[, 1], fit$mu[, 2], pch = 4, cex = 1.5, lwd = 2, col = "black")
  
  bad <- which(V == 0)
  if (length(bad) > 0)
    points(X[bad, 1], X[bad, 2], pch = 4, col = "forestgreen", lwd = 1.6, cex = 1.0)
  
  counts  <- tabulate(labels, nbins = K)
  leg_txt <- paste0("Comp ", seq_len(K), " (n=", counts, ")")
  leg_col <- comp_cols
  leg_pch <- rep(16, K)
  
  if (length(bad) > 0) {
    leg_txt <- c(leg_txt, sprintf("Flagged (V=0, n=%d)", length(bad)))
    leg_col <- c(leg_col, "forestgreen")
    leg_pch <- c(leg_pch, 4)
  }
  
  leg_txt <- c(leg_txt, "Component ellipse")
  leg_col <- c(leg_col, "black")
  leg_pch <- c(leg_pch, NA)
  leg_lty <- c(rep(NA, length(leg_txt) - 1), 2)
  
  legend(legend_pos, legend = leg_txt, col = leg_col, pch = leg_pch,
         lty = leg_lty, pt.cex = 0.9, cex = 0.85, bty = "n", lwd = 1.4)
  
  invisible(NULL)
}


################################################################################
##  5. EVALUATION
################################################################################

eval_fit <- function(sim, fit) {
  n        <- nrow(sim$X)
  is_true  <- rep(FALSE, n); is_true[sim$contam_idx] <- TRUE                    #which points really are contaminated
  is_flag  <- fit$V == 0L                                                       #what the fit flagged
  
  TP <- sum(is_flag &  is_true)                                                 #flagged and genuinely contaminated
  FP <- sum(is_flag & !is_true)                                                 #flagged but actually clean
  FN <- sum(!is_flag &  is_true)                                                #missed contamination
  
  precision <- if (TP + FP > 0) TP / (TP + FP) else NA_real_                    #of what is flagged, how much was real
  recall    <- if (TP + FN > 0) TP / (TP + FN) else NA_real_                    #of the real contamination, how much was caught
  f1        <- if (!is.na(precision) && !is.na(recall) && precision + recall > 0)
    2 * precision * recall / (precision + recall) else NA_real_                 #harmonic mean of the two
  
  list(TP = TP, FP = FP, FN = FN,
       precision = precision, recall = recall, f1 = f1)
}

## ---- geometry of a fit: the check that catches collapsed clusters ----------
min_sep <- function(mu) {                                                       # smallest distance between any two component means
  mu <- as.matrix(mu)
  if (nrow(mu) < 2 || anyNA(mu)) return(NA_real_)
  min(dist(mu))
}

comp_trace <- function(Sigma) {                                                 # average variance per component
  if (anyNA(Sigma)) return(rep(NA_real_, dim(Sigma)[3]))
  vapply(seq_len(dim(Sigma)[3]), function(k) mean(diag(Sigma[, , k])), numeric(1))
}

ellipses_overlap <- function(mu, Sigma, level = 0.95) {                         # centres closer than the two major radii
  mu <- as.matrix(mu)
  if (anyNA(mu) || anyNA(Sigma) || nrow(mu) < 2) return(NA)
  c2  <- qchisq(level, df = ncol(mu))
  rad <- vapply(seq_len(dim(Sigma)[3]), function(k)
    sqrt(max(eigen(Sigma[, , k], symmetric = TRUE, only.values = TRUE)$values) * c2),
    numeric(1))
  D <- as.matrix(dist(mu))
  any(sapply(seq_len(nrow(mu) - 1), function(i)
    any(D[i, (i + 1):nrow(mu)] < rad[i] + rad[(i + 1):nrow(mu)])))
}

################################################################################
## 6. Configuration this is the only place to edit
################################################################################
# alpha deliberately has NO default. A run must say which contamination level
# it is: a forgotten alpha is a silent wrong answer, a missing one is an error
# on line one. Set it once in Section 6.1 below.
#
# pie / mu / Sigma / alpha / bounds are the TRUE data-generating parameters:
# used by rGMM to draw the data and, at the end, as the scoring target. No
# fitting routine reads them, except the oracle path fit_one(init = "true").
#
# init:      "tkmeans" trimmed kmeans, robust to contamination   <- default
#            "kmeans"  plain kmeans, kept for comparison
#            "true"    ORACLE, benchmark only
# eig_ratio: cap on the eigenvalue ratio across components; Inf disables it.
# spl$prop_cut: NULL derives alpha + 0.20, capped by the identifiability
#            ceiling. Fixing it at 0.50 makes the schedule inert once
#            alpha reaches 0.50.
# spl$target_cut: NULL ties it to alpha. Note this hands SPL the true
#            contamination fraction, which is itself an oracle; set it
#            explicitly to study a misspecified trimming level.
# xlsx_mode: "files" one file per replicate  <- default
#            "sheets" one workbook, R sheets
#            "long"   one workbook, stacked
#            "both"   "files" AND "long"
# xlsx_ext:  "xlsx" or "csv" for the per-replicate files.
################################################################################

make_cfg <- function(alpha,                                                     # CONTAMINATION FRACTION -- REQUIRED, no default
                     R         = 500,                                           # replicate datasets
                     n         = 500,                                           # observations per dataset
                     base_seed = 2026L,                                         # replicate r uses base_seed + r
                     bounds    = c(-10, 10),                                    # uniform noise range
                     pie       = c(0.7, 0.3),
                     mu        = matrix(c(-3, -3,
                                          3,  3), nrow = 2, byrow = TRUE),
                     Sigma     = NULL,                                          # NULL -> identity for every component
                     out_dir   = "sims",                                        # where all output is written
                     xlsx_mode = "files",                                       # "files" | "sheets" | "long" | "both"
                     xlsx_ext  = "xlsx",                                        # "xlsx" | "csv"
                     init      = "tkmeans",                                     # "tkmeans" | "kmeans" | "true"
                     model     = "VVV",                                         # mclust covariance model
                     eig_ratio = 20,                                            # eigenvalue-ratio cap; Inf = off
                     cut_margin = 0.20,                                         # prop_cut = alpha + this
                     spl       = list(prop_cut   = NULL,                        # NULL -> derived from alpha
                                      cut_decay  = 0.05,
                                      target_cut = NULL,                        # NULL -> tied to alpha
                                      max_outer  = 300,                       # annealing needs the headroom; see snap_tol
                                      max_inner  = 100,
                                      tol        = 1e-6)) {
  
  if (missing(alpha))                                                           # alpha is never assumed: a run must declare its scenario
    stop("make_cfg(): alpha has no default. Set ALPHA in Section 6.1, ",
         "or call make_cfg(alpha = <value>) directly.")
  
  K <- length(pie)                                                              # components
  d <- ncol(mu)                                                                 # dimensions
  
  if (is.null(Sigma)) {                                                         # default: K identity matrices
    Sigma <- array(0, c(d, d, K))
    for (k in seq_len(K)) Sigma[, , k] <- diag(d)
  }
  
  if (is.null(spl$target_cut)) spl$target_cut <- alpha                          # keep SPL target tied to contamination
  
  cut_ceiling <- 1 - (K * (d + 1) + 1) / n                                      # same bound gmm_em_spl enforces
  if (is.null(spl$prop_cut))                                                    # start above the target so annealing does work
    spl$prop_cut <- min(spl$target_cut + cut_margin, 0.9 * cut_ceiling)
  
  ## ---- validation: fail loudly at config time, not 300 replicates in ----
  stopifnot(
    R >= 1, n >= 1,
    alpha >= 0, alpha < 1,
    length(bounds) == 2, bounds[1] < bounds[2],
    abs(sum(pie) - 1) < 1e-8,                                                   # mixing weights sum to one
    nrow(mu) == K,                                                              # one mean vector per component
    dim(Sigma)[3] == K,                                                         # one covariance per component
    dim(Sigma)[1] == d, dim(Sigma)[2] == d,                                     # covariances match mu's dimension
    xlsx_mode %in% c("files", "sheets", "long", "both"),
    xlsx_ext  %in% c("xlsx", "csv"),
    init      %in% c("tkmeans", "kmeans", "true"),
    spl$prop_cut >= 0, spl$prop_cut < 1,
    spl$target_cut >= 0, spl$target_cut < 1,
    eig_ratio > 1
  )
  
  if (spl$prop_cut < spl$target_cut - 1e-10)
    warning("prop_cut < target_cut: the schedule anneals UPWARD, trimming ",
            "too little early on. Raise cut_margin or n.")
  
  cfg <- list(R = R, n = n, base_seed = base_seed,
              alpha = alpha, bounds = bounds,
              pie = pie, mu = mu, Sigma = Sigma,
              K = K, d = d,
              out_dir = out_dir, xlsx_mode = xlsx_mode, xlsx_ext = xlsx_ext,
              init = init, model = model, eig_ratio = eig_ratio,
              cut_margin = cut_margin, spl = spl,
              R_version = R.version.string)
  
  ## ---- derived paths: filenames can never disagree with the design ------
  cfg$stem      <- sprintf("sims_gmm_R%d_n%d_a%02d", R, n, round(100 * alpha))
  cfg$rds_path  <- file.path(out_dir, paste0(cfg$stem, ".rds"))
  cfg$csv_path  <- file.path(out_dir, paste0(cfg$stem, "_long.csv"))
  cfg$seed_path <- file.path(out_dir, paste0(cfg$stem, "_seeds.csv"))
  cfg$fit_path  <- file.path(out_dir, paste0(cfg$stem, "_fits.rds"))
  cfg$xlsx_dir  <- file.path(out_dir, cfg$stem)                                 # folder for the per-replicate files
  
  cfg
}


################################################################################
## 6.1 The one knob for which contamination level it runs for
################################################################################
# Change ALPHA, source the file again. That is the whole workflow.
################################################################################

ALPHA <- 0.05                                                                   # <<<<<< EDIT ME BETWEEN RUNS

.cli <- suppressWarnings(as.numeric(commandArgs(trailingOnly = TRUE)[1]))        # command line wins if given
if (!is.na(.cli)) {
  if (.cli < 0 || .cli >= 1) stop("alpha from the command line must be in [0, 1): got ", .cli)
  ALPHA <- .cli
}


################################################################################
# 6.2 What is saved
################################################################################
#
#   sims/sims_gmm_R500_n500_...../                        the DATASETS,
#                                                         one file per replicate
#   sims/sims_gmm_R500_n500_...._means_store.csv          every MEAN ESTIMATE,
#                                                         EM and SPL, one row per
#                                                         (replicate, method, component)
#   sims/sims_gmm_R500_n500_....._bias_mse.xlsx           BIAS and MSE per component
#   sims/sims_gmm_R500_n500_..._bias_mse_overall.xlsx     BIAS and MSE per method
#
################################################################################

SAVE <- list(datasets      = TRUE,                                              # per-replicate dataset files  <- KEEP
             overall       = TRUE,                                              # Bias / MSE per method        <- KEEP
             means_store   = TRUE,                                              # every mean estimate, EM and SPL  <- KEEP
             per_component = TRUE,                                              # Bias / MSE per component     <- KEEP
             workbook      = FALSE,                                             # all three as one xlsx
             rds           = FALSE,                                             # native R copy of every dataset
             seeds         = FALSE)                                             # rep -> seed table

CFG <- make_cfg(alpha = ALPHA)                                                  # the single scenario for this run
dir.create(CFG$out_dir, showWarnings = FALSE, recursive = TRUE)

cat(sprintf("\n>>> RUN SCENARIO: alpha = %.2f | R = %d | n = %d | init = %s\n",
            CFG$alpha, CFG$R, CFG$n, CFG$init))
cat(sprintf(">>> all output for this run is stemmed:  %s\n", CFG$stem))

################################################################################
##  7. STUDY HELPERS  (everything reads from cfg; no constants below this line)
################################################################################
# One seed per replicate (base_seed + r) rather than one seed for the whole
# loop: any single replicate can be reproduced in isolation.
################################################################################
## ---- 7.1 plain kmeans initialisation ---------------------------------------
# Kept for comparison. Every point must be assigned, so at high contamination
# the noise pulls the centres together and inflates the covariances. Use
# init_tkmeans() for the study.
################################################################################

init_kmeans <- function(X, K, seed = NULL, nstart = 25, iter_max = 50, ...) {
  
  X <- as.matrix(X); n <- nrow(X); d <- ncol(X)
  if (!is.null(seed)) set.seed(seed)                                            # kmeans is randomised; make the init reproducible
  
  km <- kmeans(X, centers = K, nstart = nstart, iter.max = iter_max)            # nstart > 1 guards against a poor local optimum
  
  cl  <- as.integer(km$cluster)
  mu  <- matrix(as.numeric(km$centers), K, d)                                   # strip dimnames; rows ordered by cluster label
  pie <- as.numeric(tabulate(cl, nbins = K)) / n                                # cluster shares as starting mixing weights
  
  S_pool <- cov(X) + diag(1e-6, d)                                              # fallback for clusters too small to estimate from
  Sigma  <- array(0, c(d, d, K))
  for (k in seq_len(K)) {
    idx <- which(cl == k)
    Sigma[, , k] <- if (length(idx) > d) cov(X[idx, , drop = FALSE]) + diag(1e-6, d) else S_pool
  }
  
  z <- matrix(0, n, K)                                                          # hard responsibilities for mclust
  z[cbind(seq_len(n), cl)] <- 1
  
  pie[pie <= 0] <- 1e-8; pie <- pie / sum(pie)                                  # no exactly-empty component
  
  list(pie = pie, mu = mu, Sigma = Sigma, z = z, cluster = cl,
       kept = rep(TRUE, n), tot_withinss = km$tot.withinss, init = "kmeans")
}

## ---- 7.2 trimmed kmeans initialisation
# Alternates: assign every point to its nearest centre, drop the worst `trim`
# fraction by distance to that centre, recompute the centres from the
# survivors only. The kmeans analogue of what SPL does, so the start already
# sits on the Gaussians instead of between them.
#
# Restarts are scored on TRIMMED within-cluster sum of squares, so a start
# that parks a centre in the noise cannot win.
#
# Same return shape as init_kmeans, including the z matrix mclust needs.
################################################################################

init_tkmeans <- function(X, K, seed = NULL, trim = NULL, cfg = CFG,
                         nstart = 20, iter_max = 30, ...) {
  
  X <- as.matrix(X); n <- nrow(X); d <- ncol(X)
  if (is.null(trim)) trim <- cfg$spl$target_cut                                 # trim at the expected contamination
  trim <- min(max(trim, 0), 0.9)
  if (!is.null(seed)) set.seed(seed)
  
  n_keep <- max(K * (d + 1) + 1, n - floor(trim * n))                           # never trim below identifiability
  n_keep <- min(n_keep, n)
  
  best <- NULL
  for (s in seq_len(nstart)) {
    
    ctr <- X[sample.int(n, K), , drop = FALSE]                                  # random points as starting centres
    D <- matrix(0, n, K); cl <- integer(n); keep <- rep(TRUE, n)
    
    for (it in seq_len(iter_max)) {
      for (k in seq_len(K)) D[, k] <- colSums((t(X) - ctr[k, ])^2)              # squared distance to each centre
      cl <- max.col(-D, ties.method = "first")                                  # nearest centre
      dm <- D[cbind(seq_len(n), cl)]                                            # distance to own centre
      
      keep <- rep(FALSE, n)
      keep[order(dm)[seq_len(n_keep)]] <- TRUE                                  # the n_keep closest points survive
      
      ctr_new <- ctr
      for (k in seq_len(K)) {
        idx <- which(keep & cl == k)
        if (length(idx)) ctr_new[k, ] <- colMeans(X[idx, , drop = FALSE])       # centres from survivors only
      }
      if (max(abs(ctr_new - ctr)) < 1e-8) { ctr <- ctr_new; break }
      ctr <- ctr_new
    }
    
    obj <- sum(D[cbind(seq_len(n), cl)][keep])                                  # TRIMMED within-cluster sum of squares
    if (is.null(best) || obj < best$obj)
      best <- list(obj = obj, ctr = ctr, cl = cl, keep = keep)
  }
  
  cl <- best$cl; keep <- best$keep
  mu <- matrix(as.numeric(best$ctr), K, d)
  
  pie <- vapply(seq_len(K), function(k) sum(keep & cl == k), numeric(1))
  pie <- pie / max(sum(pie), 1)
  pie[pie <= 0] <- 1e-8; pie <- pie / sum(pie)
  
  S_pool <- cov(X[keep, , drop = FALSE]) + diag(1e-6, d)
  Sigma  <- array(0, c(d, d, K))
  for (k in seq_len(K)) {
    idx <- which(keep & cl == k)                                                # covariance from survivors only
    Sigma[, , k] <- if (length(idx) > d) cov(X[idx, , drop = FALSE]) + diag(1e-6, d) else S_pool
  }
  
  z <- matrix(0, n, K)                                                          # mclust needs every row to sum to 1, so the
  z[cbind(seq_len(n), cl)] <- 1                                                 # trimmed points keep their hard label here
  
  list(pie = pie, mu = mu, Sigma = Sigma, z = z, cluster = cl,
       kept = keep, trim = trim, tot_withinss = best$obj, init = "tkmeans")
}

## ---- 7.3 simulation --------------------------------------------------------
simulate_one <- function(r, cfg = CFG) {                                        # replicate r, on demand
  sim <- rGMM(n = cfg$n, pie = cfg$pie, mu = cfg$mu, Sigma = cfg$Sigma,         # TRUE parameters: generation only
              alpha = cfg$alpha, bounds = cfg$bounds,
              seed = cfg$base_seed + r)
  sim$rep   <- r                                                                # provenance travels with the data
  sim$seed  <- cfg$base_seed + r
  sim$alpha <- cfg$alpha                                                        # so an exported sheet is self-describing
  sim
}

simulate_many <- function(cfg = CFG, verbose = TRUE) {
  
  sims <- vector("list", cfg$R)                                                 # pre-allocate, never grow in a loop
  for (r in seq_len(cfg$R)) {
    sims[[r]] <- simulate_one(r, cfg)
    if (verbose && r %% 50 == 0) cat(sprintf("  generated %3d / %d\n", r, cfg$R))
  }
  attr(sims, "cfg")       <- cfg                                                # design travels with the data
  attr(sims, "generated") <- Sys.time()
  sims
}


## ---- 7.4 the starting values for one replicate -----------------------------
# The single place that decides what an estimator may start from. The init
# seed is derived from the replicate seed, offset so the init RNG never
# collides with the data RNG: replicate r is reproducible end to end from
# cfg$base_seed + r alone.
################################################################################

start_values <- function(sim, cfg = CFG, init = cfg$init) {
  
  init <- match.arg(init, c("tkmeans", "kmeans", "true"))
  X    <- as.matrix(sim$X)
  seed <- sim$seed + 100000L
  
  st <- switch(init,
               true    = list(pie = cfg$pie, mu = cfg$mu, Sigma = cfg$Sigma, z = NULL,     # ORACLE: benchmark only
                              cluster = NULL, kept = NULL),
               kmeans  = init_kmeans(X,  cfg$K, seed = seed),
               tkmeans = init_tkmeans(X, cfg$K, seed = seed, cfg = cfg))
  
  st$init <- init                                                               # the label travels with the values
  st
}

## ---- 7.5 fitting -----------------------------------------------------------
fit_one <- function(sim, cfg = CFG, init = cfg$init, verbose = FALSE) {
  
  st <- start_values(sim, cfg, init)
  
  f <- gmm_em_spl(sim$X, st$pie, st$mu, st$Sigma,
                  prop_cut   = cfg$spl$prop_cut,
                  target_cut = cfg$spl$target_cut,
                  cut_decay  = cfg$spl$cut_decay,
                  eig_ratio  = cfg$eig_ratio,
                  max_outer  = cfg$spl$max_outer,
                  max_inner  = cfg$spl$max_inner,
                  tol        = cfg$spl$tol,
                  verbose    = verbose)
  f$init   <- st$init                                                           # so a saved fit says how it was started
  f$method <- "SPL"
  f
}

fit_all <- function(sims, cfg = attr(sims, "cfg"), init = cfg$init, verbose = FALSE) {
  fits <- vector("list", length(sims))
  for (r in seq_along(sims)) {
    fits[[r]] <- fit_one(sims[[r]], cfg, init = init)
    if (verbose && r %% 50 == 0) cat(sprintf("  fitted %3d / %d\n", r, length(sims)))
  }
  attr(fits, "cfg")  <- cfg
  attr(fits, "init") <- init
  fits
}

## ---- 7.6 scoring across replicates -----------------------------------------
score_all <- function(sims, fits, cfg = attr(sims, "cfg")) {
  stopifnot(length(sims) == length(fits))
  do.call(rbind, Map(function(s, f) {
    e <- eval_fit(s, f)
    data.frame(alpha = cfg$alpha, rep = s$rep,
               init  = if (is.null(f$init)) NA_character_ else f$init,          # which start produced this row
               TP = e$TP, FP = e$FP, FN = e$FN,
               precision = e$precision, recall = e$recall, f1 = e$f1,
               sep = min_sep(f$mu),                                             # geometry check: has the fit collapsed?
               overlap = ellipses_overlap(f$mu, f$Sigma),
               loglik = f$loglik, converged = f$converged,
               outer = f$iters$outer,
               stringsAsFactors = FALSE)
  }, sims, fits))
}

## ---- 7.7 saving (native R) -------------------------------------------------
save_rds <- function(sims, cfg = attr(sims, "cfg")) {                           # native R types, one file
  saveRDS(sims, cfg$rds_path, compress = "xz")
  cat("Saved:", cfg$rds_path, sprintf("(%.1f MB)\n", file.size(cfg$rds_path) / 1024^2))
  invisible(cfg$rds_path)
}

save_seeds <- function(cfg = CFG) {                                             # cheapest reproducibility
  seed_table <- data.frame(rep  = seq_len(cfg$R),
                           seed = cfg$base_seed + seq_len(cfg$R))
  write.csv(seed_table, cfg$seed_path, row.names = FALSE)
  cat("Saved:", cfg$seed_path, "\n")
  invisible(seed_table)
}

write_long_csv <- function(sims, cfg = attr(sims, "cfg")) {                     # plain-text alternative to Excel
  long <- do.call(rbind, lapply(sims, sim_to_df))
  write.csv(long, cfg$csv_path, row.names = FALSE)
  cat("Saved:", cfg$csv_path, sprintf("(%d rows)\n", nrow(long)))
  invisible(long)
}

## ---- 7.8 sanity check ------------------------------------------------------
sanity_check <- function(sims, cfg = attr(sims, "cfg")) {
  chk <- vapply(sims, function(s) length(s$contam_idx), integer(1))
  cat(sprintf("Contaminated per replicate: min %d, mean %.1f, max %d (expected %d)\n",
              min(chk), mean(chk), max(chk), floor(cfg$alpha * cfg$n)))
  stopifnot(identical(sims[[1]]$X, simulate_one(1, cfg)$X))                     # seed-only route reproduces stored data
  cat("Seed reproducibility check passed.\n")
  invisible(chk)
}


################################################################################
##  8. EXPORT
################################################################################
# Columns: rep, seed, alpha, obs, X1 ... Xd, label, contaminated
#   label        0 = contaminated, k = drawn from component k
#   contaminated 0/1 flag, so you can filter directly in Excel
################################################################################

xlsx_engine <- function() {                                                     # pick whichever package is installed
  if (requireNamespace("openxlsx", quietly = TRUE)) return("openxlsx")
  if (requireNamespace("writexl",  quietly = TRUE)) return("writexl")
  stop("Install an Excel writer first:  install.packages(\"openxlsx\")")
}

write_xlsx_any <- function(x, path, engine = xlsx_engine()) {                    # x = data.frame OR named list of them
  if (engine == "openxlsx") openxlsx::write.xlsx(x, file = path)
  else                      writexl::write_xlsx(x, path = path)
  invisible(path)
}

write_table_any <- function(df, dir, name, ext = "xlsx") {                       # one data frame -> one file, xlsx or csv
  path <- file.path(dir, paste0(name, ".", ext))
  if (ext == "csv") write.csv(df, path, row.names = FALSE)
  else              write_xlsx_any(df, path)
  cat("Saved:", path, sprintf("(%d rows)\n", nrow(df)))
  invisible(path)
}

sim_to_df <- function(s) {                                                      # one replicate -> tidy data frame
  X  <- as.matrix(s$X)
  df <- data.frame(rep   = s$rep,
                   seed  = s$seed,
                   alpha = if (is.null(s$alpha)) NA_real_ else s$alpha,
                   obs   = seq_len(nrow(X)))
  for (j in seq_len(ncol(X))) df[[paste0("X", j)]] <- X[, j]                    # X1 ... Xd, works for any dimension
  df$label        <- s$labels                                                   # 0 = contaminated, k = component k
  df$contaminated <- as.integer(s$labels == 0L)                                 # explicit flag for Excel filtering
  df
}

write_one_rep <- function(s, dir, pad, ext = "xlsx", engine = NULL) {           # one replicate -> one file
  path <- file.path(dir, sprintf("rep_%0*d.%s", pad, s$rep, ext))
  if (ext == "csv") write.csv(sim_to_df(s), path, row.names = FALSE)
  else              write_xlsx_any(sim_to_df(s), path, engine)
  path
}

export_xlsx <- function(sims, cfg = attr(sims, "cfg"),
                        mode = cfg$xlsx_mode, ext = cfg$xlsx_ext, verbose = TRUE) {
  
  mode <- match.arg(mode, c("files", "sheets", "long", "both"))
  ext  <- match.arg(ext,  c("xlsx", "csv"))
  pad  <- nchar(as.character(length(sims)))                                     # zero-pad so files sort correctly
  
  if (mode == "both") {                                                         # per-replicate files AND one stacked sheet
    a <- export_xlsx(sims, cfg, mode = "files", ext = ext, verbose = verbose)
    b <- export_xlsx(sims, cfg, mode = "long",  ext = ext, verbose = verbose)
    return(invisible(c(a, b)))
  }
  
  engine <- if (mode == "files" && ext == "csv") NULL else xlsx_engine()        # only load a writer if one is needed
  
  if (mode == "files") {                                                        # ALL R replicates, one file each
    dir.create(cfg$xlsx_dir, showWarnings = FALSE, recursive = TRUE)
    for (r in seq_along(sims)) {
      write_one_rep(sims[[r]], cfg$xlsx_dir, pad, ext, engine)
      if (verbose && r %% 50 == 0) cat(sprintf("  wrote %3d / %d\n", r, length(sims)))
    }
    cat("Saved", length(sims), sprintf("%s files to: %s\n", toupper(ext), cfg$xlsx_dir))
    return(invisible(cfg$xlsx_dir))
  }
  
  if (mode == "sheets") {
    sheets <- lapply(sims, sim_to_df)
    names(sheets) <- sprintf("rep_%0*d", pad, vapply(sims, function(s) s$rep, integer(1)))
    path <- file.path(cfg$out_dir, paste0(cfg$stem, ".xlsx"))
    write_xlsx_any(sheets, path, engine)
    cat("Saved:", path, sprintf("(%d sheets)\n", length(sheets)))
    return(invisible(path))
  }
  
  long <- do.call(rbind, lapply(sims, sim_to_df))                               # mode == "long"
  stopifnot(nrow(long) < 1048576)                                               # Excel's hard row limit
  path <- file.path(cfg$out_dir, paste0(cfg$stem, "_long.xlsx"))
  write_xlsx_any(long, path, engine)
  cat("Saved:", path, sprintf("(%d rows)\n", nrow(long)))
  invisible(path)
}

check_exports <- function(cfg = CFG, ext = cfg$xlsx_ext) {                      # did every replicate reach disk?
  if (!dir.exists(cfg$xlsx_dir)) {
    cat("No per-replicate folder at:", cfg$xlsx_dir, "\n"); return(invisible(NULL))
  }
  files <- list.files(cfg$xlsx_dir, pattern = sprintf("^rep_\\d+\\.%s$", ext))
  cat(sprintf("Per-replicate files: %d found, %d expected -> %s\n",
              length(files), cfg$R, if (length(files) == cfg$R) "OK" else "MISMATCH"))
  invisible(files)
}


################################################################################
##  9. DEMONSTRATION  (function; called from Section 15)
################################################################################
# Uses the SAME start as the study, so these numbers agree with the rep == 1
# rows of the Monte Carlo output.
################################################################################

run_demo <- function(cfg = CFG, r = 1, init = cfg$init, plot = TRUE) {
  
  cat("\n================ SPL-EM GMM DEMONSTRATION ================\n")
  cat(sprintf("init = %s | eig_ratio = %s | prop_cut %.2f -> target_cut %.2f\n\n",
              init, format(cfg$eig_ratio), cfg$spl$prop_cut, cfg$spl$target_cut))
  
  sim <- simulate_one(r, cfg)                                                   # same data the Monte Carlo uses as rep r
  fit <- fit_one(sim, cfg, init = init, verbose = TRUE)
  
  if (plot && cfg$d == 2) plt_gmm(sim$X, fit, 0.95)                             # scatter + 95% ellipse + flagged points
  
  ev <- eval_fit(sim, fit)
  
  cat("\n---------------- RESULTS ----------------\n")
  cat("Contamination alpha:   ", cfg$alpha, "\n")
  cat("True contaminated:     ", length(sim$contam_idx), "\n")
  cat("Detected (V == 0):     ", sum(fit$V == 0), "\n")
  cat(sprintf("Precision / Recall / F1: %.3f / %.3f / %.3f\n",
              ev$precision, ev$recall, ev$f1))
  cat("Trimmed log-likelihood:", round(fit$loglik, 4), "\n")
  cat("Final lambda:          ", round(fit$lambda, 4), "\n")
  cat("Outer / inner iters:   ", fit$iters$outer, "/", fit$iters$inner, "\n")
  cat(sprintf("Separation of means:    %.3f  (true %.3f)%s\n",
              min_sep(fit$mu), min_sep(cfg$mu),
              if (isTRUE(ellipses_overlap(fit$mu, fit$Sigma))) "   <- ELLIPSES OVERLAP" else ""))
  cat("Estimated means (true:", paste(apply(cfg$mu, 1, function(m)
    sprintf("(%s)", paste(m, collapse = ","))), collapse = " and "), "):\n")
  print(round(fit$mu, 3))
  cat("Estimated weights (true:", paste(cfg$pie, collapse = " / "), "):",
      round(fit$pie, 3), "\n")
  cat("Estimated covariances:\n"); print(round(fit$Sigma, 3))
  
  invisible(list(sim = sim, fit = fit, eval = ev))
}


################################################################################
##  10. MONTE CARLO RUN  (function; called from Section 15)
################################################################################

run_monte_carlo <- function(cfg = CFG, export = TRUE, keep = SAVE, verbose = TRUE) {
  
  cat("\nGenerating", cfg$R, "datasets of n =", cfg$n, "at alpha =", cfg$alpha, "...\n")
  
  sims <- simulate_many(cfg, verbose = verbose)
  sanity_check(sims, cfg)                                                       # in memory either way: costs nothing
  if (isTRUE(keep$rds))   save_rds(sims, cfg)                                   # off by default
  if (isTRUE(keep$seeds)) save_seeds(cfg)                                       # off by default
  
  if (export && isTRUE(keep$datasets)) {
    export_xlsx(sims, cfg, verbose = verbose)
    if (cfg$xlsx_mode %in% c("files", "both")) check_exports(cfg)
  }
  sims
}


################################################################################
##  11. CONTAMINATION SWEEP  (all replicates, several alpha levels)
################################################################################
# Each level gets its own cfg, .rds and export folder, with alpha baked into
# every path so nothing overwrites anything else. prop_cut is re-derived per
# level, so the annealing schedule stays meaningful at every alpha.
################################################################################

run_alpha_sweep <- function(alphas       = c(0.00, 0.05, 0.10, 0.20),
                            fit          = FALSE,                               # also fit and score each level
                            init         = "tkmeans",                           # SPL start when fit = TRUE
                            save_rds_too = TRUE,
                            verbose      = TRUE,
                            ...) {                                              # -> make_cfg
  
  cfgs   <- vector("list", length(alphas))
  scores <- NULL
  names(cfgs) <- sprintf("a%02d", round(100 * alphas))
  
  for (i in seq_along(alphas)) {
    cfg <- make_cfg(alpha = alphas[i], init = init, ...)                        # validation runs here, before any work
    dir.create(cfg$out_dir, showWarnings = FALSE, recursive = TRUE)
    
    cat(sprintf("\n=== alpha = %.2f | R = %d | n = %d | init = %s | cut %.2f -> %.2f ===\n",
                cfg$alpha, cfg$R, cfg$n, init, cfg$spl$prop_cut, cfg$spl$target_cut))
    
    sims_i <- simulate_many(cfg, verbose = verbose)
    sanity_check(sims_i, cfg)
    if (save_rds_too) save_rds(sims_i, cfg)
    save_seeds(cfg)
    export_xlsx(sims_i, cfg, verbose = verbose)
    if (cfg$xlsx_mode %in% c("files", "both")) check_exports(cfg)
    
    if (fit) {
      fits_i <- fit_all(sims_i, cfg, init = init, verbose = verbose)
      saveRDS(fits_i, cfg$fit_path, compress = "xz")
      s_i    <- score_all(sims_i, fits_i, cfg)
      scores <- rbind(scores, s_i)
      cat(sprintf("  mean precision / recall / F1: %.3f / %.3f / %.3f | mean sep %.2f (true %.2f) | overlap in %d%% of reps\n",
                  mean(s_i$precision, na.rm = TRUE), mean(s_i$recall, na.rm = TRUE),
                  mean(s_i$f1, na.rm = TRUE), mean(s_i$sep, na.rm = TRUE),
                  min_sep(cfg$mu), round(100 * mean(s_i$overlap, na.rm = TRUE))))
    }
    
    cfgs[[i]] <- cfg
    rm(sims_i); gc()                                                            # don't hold every level in memory at once
  }
  
  if (!is.null(scores)) {
    out_dir <- cfgs[[1]]$out_dir
    path    <- file.path(out_dir, sprintf("scores_all_alphas_%s.xlsx", init))   # init in the filename, not just the column
    write_xlsx_any(scores, path)
    cat("\nSaved:", path, "\n")
  }
  
  cat("\nSweep complete.\n")
  invisible(list(cfgs = cfgs, scores = scores))
}


################################################################################
##  12. TWO-METHOD COMPARISON: classical EM (mclust) vs SPL-EM
################################################################################
#  Things to nate on the shared start
#    mclust takes the start as the hard 0/1 matrix z and runs its own M-step
#    from it; gmm_em_spl takes pie/mu/Sigma directly. Both describe the same
#    partition. The starting covariances differ slightly because init_tkmeans
#    computes them from survivors only while mclust's M-step uses every point
#    in z. That difference is part of what the trimming buys and is stated
#    rather than hidden.
#
#  Something to also note on LIKELIHOODS
#    mclust reports the FULL log-likelihood over all n points; gmm_em_spl
#    reports the TRIMMED log-likelihood over kept points only. Carried side
#    by side for reference but NOT comparable.
################################################################################

## ---- 12.1 classical EM via mclust ------------------------------------------
# Arguments are passed by NAME because the positional order of me() has
# changed across mclust versions.
#   modelName = "VVV"  unconstrained, matching gmm_em_spl
#               "EII"  spherical, equal volume (the true generating model)
################################################################################


mclust_sigma_array <- function(v, d, K) {                                       # variance objects differ by modelName
  if (!is.null(v$sigma))   return(array(v$sigma, c(d, d, K)))                   # most models expose sigma directly
  if (!is.null(v$Sigma))   return(array(rep(as.numeric(v$Sigma), K), c(d, d, K)))  # common-covariance models
  if (!is.null(v$sigmasq)) {                                                    # spherical models
    s2  <- rep_len(as.numeric(v$sigmasq), K)
    out <- array(0, c(d, d, K))
    for (k in seq_len(K)) out[, , k] <- diag(s2[k], d)
    return(out)
  }
  array(NA_real_, c(d, d, K))
}


## mclust::me() dispatches internally to meVVV() / meEII() etc BY NAME, and
## those are only visible once the package is ATTACHED. requireNamespace() on
## its own is not enough: me() then fails with "could not find function meVVV",
## the tryCatch below swallows it, and every EM fit comes back NA. Attach once.
ensure_mclust <- function() {
  if (!requireNamespace("mclust", quietly = TRUE))
    stop("Install mclust first:  install.packages(\"mclust\")")
  if (!"package:mclust" %in% search())
    suppressPackageStartupMessages(library(mclust))
  invisible(TRUE)
}

fit_em <- function(X, init, modelName = "VVV") {
  
  ensure_mclust()
  if (is.null(init$z))
    stop("fit_em needs a z matrix; the \"true\" oracle start has none.")
  
  X <- as.matrix(X); d <- ncol(X); K <- ncol(init$z)
  
  na_fit <- list(pie = rep(NA_real_, K), mu = matrix(NA_real_, K, d),
                 Sigma = array(NA_real_, c(d, d, K)),
                 loglik = NA_real_, converged = FALSE,
                 modelName = modelName, method = "EM",
                 init = if (is.null(init$init)) NA_character_ else init$init)
  
  em <- tryCatch(mclust::me(data = X, modelName = modelName, z = init$z),
                 error = function(e) NULL)                                      # a failed fit must not kill the replicate loop
  
  if (is.null(em) || is.null(em$parameters) || !is.finite(em$loglik)) return(na_fit)
  
  mu <- t(matrix(as.numeric(em$parameters$mean), d, K))                         # mclust stores means d x K; we want K x d
  
  list(pie       = as.numeric(em$parameters$pro),
       mu        = mu,
       Sigma     = mclust_sigma_array(em$parameters$variance, d, K),
       loglik    = as.numeric(em$loglik),                                       # FULL log-likelihood (all n points)
       converged = is.null(attr(em, "warn")),
       modelName = modelName,
       method    = "EM",
       init      = if (is.null(init$init)) NA_character_ else init$init)
}


## ---- 12.2 SPL-EM from a supplied start -------------------------------------
fit_spl_init <- function(X, init, cfg = CFG, verbose = FALSE) {
  
  f <- gmm_em_spl(X, init$pie, init$mu, init$Sigma,
                  prop_cut   = cfg$spl$prop_cut,
                  target_cut = cfg$spl$target_cut,
                  cut_decay  = cfg$spl$cut_decay,
                  eig_ratio  = cfg$eig_ratio,
                  max_outer  = cfg$spl$max_outer,
                  max_inner  = cfg$spl$max_inner,
                  tol        = cfg$spl$tol,
                  verbose    = verbose)
  f$method    <- "SPL"
  f$modelName <- "VVV"                                                          # gmm_em_spl always fits unconstrained covariances
  f$init      <- if (is.null(init$init)) NA_character_ else init$init
  f
}

## ---- 12.3 label matching ---------------------------------------------------
# EM and SPL can return the same solution under different component labels,
# so raw mu rows are not comparable. Both fits are permuted onto the TRUE
# means, the common reference.
################################################################################

all_perms <- function(K) {                                                      # every permutation of 1:K, K! x K
  if (K == 1L) return(matrix(1L, 1, 1))
  sub <- all_perms(K - 1L)
  do.call(rbind, lapply(seq_len(K), function(k) {
    rest <- setdiff(seq_len(K), k)
    cbind(k, matrix(rest[sub], nrow = nrow(sub)))
  }))
}

match_perm <- function(mu_hat, mu_true) {                                       # p such that mu_hat[p, ] aligns to mu_true
  K <- nrow(mu_true)
  if (K > 7L) stop("match_perm: enumerating all permutations is only sane for K <= 7")
  if (anyNA(mu_hat)) return(seq_len(K))                                         # failed fit: leave the order alone
  P    <- all_perms(K)
  cost <- apply(P, 1, function(p) sum((mu_hat[p, , drop = FALSE] - mu_true)^2))
  as.integer(P[which.min(cost), ])
}

relabel_fit <- function(fit, mu_true) {                                         # permute every component-indexed slot
  p <- match_perm(fit$mu, mu_true)
  fit$mu    <- fit$mu[p, , drop = FALSE]
  fit$pie   <- fit$pie[p]
  fit$Sigma <- fit$Sigma[, , p, drop = FALSE]
  if (!is.null(fit$responsibilities)) fit$responsibilities <- fit$responsibilities[, p, drop = FALSE]
  if (!is.null(fit$labels)) {                                                   # labels are values, not positions: invert the map
    inv  <- order(p)
    keep <- fit$labels > 0L
    fit$labels[keep] <- inv[fit$labels[keep]]
  }
  fit$perm <- p
  fit
}

## ---- 12.4 one replicate, both methods --------------------------------------
# ONE init call, handed to both fitters. The whole point of the comparison:
# the only thing that differs downstream is the trimming.
################################################################################

fit_both <- function(sim, cfg = CFG, modelName = cfg$model, verbose = FALSE) {
  
  X    <- as.matrix(sim$X)
  init <- start_values(sim, cfg, init = if (cfg$init == "true") "tkmeans" else cfg$init)
  
  em  <- fit_em(X, init, modelName = modelName)
  spl <- fit_spl_init(X, init, cfg, verbose = verbose)
  
  init_as_fit <- list(pie = init$pie, mu = init$mu, Sigma = init$Sigma,
                      loglik = NA_real_, converged = NA,
                      method = "init", init = init$init)
  
  list(init = relabel_fit(init_as_fit, cfg$mu),                                 # the shared start, for reference
       em   = relabel_fit(em,          cfg$mu),
       spl  = relabel_fit(spl,         cfg$mu),
       raw_init = init)
}




## ---- 12.5 tidy mean estimates ----------------------------------------------
# One row per (replicate, method, component).
################################################################################

means_to_df <- function(sim, fit, cfg = CFG, method_label = NULL) {
  
  K <- cfg$K; d <- cfg$d
  mu <- matrix(as.numeric(fit$mu), K, d)
  
  df <- data.frame(rep    = sim$rep,
                   seed   = sim$seed,
                   alpha  = if (is.null(sim$alpha)) cfg$alpha else sim$alpha,
                   method = if (is.null(method_label)) fit$method else method_label,
                   init   = if (is.null(fit$init)) NA_character_ else fit$init,
                   comp   = seq_len(K),
                   stringsAsFactors = FALSE)
  
  for (j in seq_len(d)) df[[paste0("mu", j)]]      <- mu[, j]                   # estimate
  for (j in seq_len(d)) df[[paste0("mu_true", j)]] <- cfg$mu[, j]               # target, so the file is self-describing
  for (j in seq_len(d)) df[[paste0("bias", j)]]    <- mu[, j] - cfg$mu[, j]     # signed error per coordinate
  
  df$err       <- sqrt(rowSums((mu - cfg$mu)^2))                                # Euclidean distance to the true mean
  df$pie       <- as.numeric(fit$pie)
  df$sep       <- min_sep(mu)                                                   # geometry check, same value on every row of the fit
  df$overlap   <- ellipses_overlap(mu, fit$Sigma)
  df$trace     <- comp_trace(fit$Sigma)                                         # average variance of this component
  df$converged <- if (is.null(fit$converged)) NA else fit$converged
  df$loglik    <- if (is.null(fit$loglik))    NA_real_ else fit$loglik          # EM: full; SPL: trimmed. Not comparable.
  df$n_flagged <- if (is.null(fit$V)) NA_integer_ else sum(fit$V == 0L)
  df
}

## ---- 12.6 across replicates ------------------------------------------------
compare_one <- function(sim, cfg = CFG, modelName = cfg$model, include_init = TRUE) {
  fb  <- fit_both(sim, cfg, modelName = modelName)
  out <- rbind(means_to_df(sim, fb$em,  cfg, "EM"),
               means_to_df(sim, fb$spl, cfg, "SPL"))
  if (include_init) out <- rbind(means_to_df(sim, fb$init, cfg, "init"), out)
  out
}

compare_all <- function(sims, cfg = attr(sims, "cfg"),
                        modelName = cfg$model, include_init = TRUE, verbose = TRUE) {
  
  rows <- vector("list", length(sims))                                          # pre-allocate, never grow in a loop
  for (r in seq_along(sims)) {
    rows[[r]] <- compare_one(sims[[r]], cfg, modelName, include_init)
    if (verbose && r %% 50 == 0) cat(sprintf("  fitted EM + SPL %3d / %d\n", r, length(sims)))
  }
  means <- do.call(rbind, rows)
  attr(means, "cfg") <- cfg
  means
}

summarise_means <- function(means, cfg = attr(means, "cfg")) {
  
  d   <- cfg$d
  key <- interaction(means$alpha, means$method, means$comp, drop = TRUE, sep = "|")
  
  do.call(rbind, lapply(split(means, key), function(g) {
    out <- data.frame(alpha = g$alpha[1], method = g$method[1],
                      comp = g$comp[1], reps = nrow(g), stringsAsFactors = FALSE)
    for (j in seq_len(d)) {
      mh <- g[[paste0("mu", j)]]; mt <- g[[paste0("mu_true", j)]]
      out[[paste0("mean_mu", j)]] <- mean(mh, na.rm = TRUE)
      out[[paste0("bias_mu", j)]] <- mean(mh - mt, na.rm = TRUE)                # average signed error
      out[[paste0("sd_mu",   j)]] <- sd(mh, na.rm = TRUE)                       # Monte Carlo variability
      out[[paste0("rmse_mu", j)]] <- sqrt(mean((mh - mt)^2, na.rm = TRUE))      # bias and variance together
    }
    out$mean_err     <- mean(g$err, na.rm = TRUE)                               # mean distance to the true mean
    out$rmse_err     <- sqrt(mean(g$err^2, na.rm = TRUE))
    out$mean_sep     <- mean(g$sep, na.rm = TRUE)                               # has the fit kept the clusters apart?
    out$true_sep     <- min_sep(cfg$mu)
    out$overlap_rate <- mean(as.logical(g$overlap), na.rm = TRUE)               # fraction of replicates with overlapping ellipses
    out$mean_trace   <- mean(g$trace, na.rm = TRUE)                             # inflating far above 1 = covering noise
    out$conv_rate    <- mean(as.logical(g$converged), na.rm = TRUE)
    out
  }))
}

## ---- 12.7 saving and a one-call runner -------------------------------------
means_paths <- function(cfg) list(
  csv  = file.path(cfg$out_dir, paste0(cfg$stem, "_means.csv")),
  xlsx = file.path(cfg$out_dir, paste0(cfg$stem, "_means.xlsx")),
  dir  = file.path(cfg$out_dir, paste0(cfg$stem, "_means"))                     # folder for per-replicate mean files
)

save_means <- function(means, cfg = attr(means, "cfg"), summary_df = NULL,
                       per_rep = FALSE, ext = cfg$xlsx_ext, verbose = TRUE) {
  
  p <- means_paths(cfg)
  dir.create(cfg$out_dir, showWarnings = FALSE, recursive = TRUE)
  
  write.csv(means, p$csv, row.names = FALSE)
  cat("Saved:", p$csv, sprintf("(%d rows)\n", nrow(means)))
  
  if (is.null(summary_df)) summary_df <- summarise_means(means, cfg)
  write_xlsx_any(list(means = means, summary = summary_df), p$xlsx)
  cat("Saved:", p$xlsx, "(sheets: means, summary)\n")
  
  if (per_rep) {                                                                # one mean-estimate file per replicate
    dir.create(p$dir, showWarnings = FALSE, recursive = TRUE)
    reps   <- sort(unique(means$rep))
    pad    <- nchar(as.character(max(reps)))
    engine <- if (ext == "csv") NULL else xlsx_engine()
    for (r in reps) {
      g    <- means[means$rep == r, , drop = FALSE]
      path <- file.path(p$dir, sprintf("means_rep_%0*d.%s", pad, r, ext))
      if (ext == "csv") write.csv(g, path, row.names = FALSE)
      else              write_xlsx_any(g, path, engine)
      if (verbose && r %% 50 == 0) cat(sprintf("  wrote means %3d / %d\n", r, length(reps)))
    }
    cat("Saved", length(reps), "per-replicate mean files to:", p$dir, "\n")
  }
  invisible(p)
}

run_em_vs_spl <- function(cfg = CFG, sims = NULL, modelName = cfg$model,
                          include_init = TRUE, per_rep = FALSE, verbose = TRUE) {
  
  if (is.null(sims)) sims <- simulate_many(cfg, verbose = verbose)              # reuse existing sims if you have them
  
  cat(sprintf("\n=== EM (%s) vs SPL-EM | alpha = %.2f | R = %d | n = %d ===\n",
              modelName, cfg$alpha, cfg$R, cfg$n))
  cat(sprintf("Shared start: %s, one per replicate | eig_ratio = %s | cut %.2f -> %.2f\n\n",
              cfg$init, format(cfg$eig_ratio), cfg$spl$prop_cut, cfg$spl$target_cut))
  
  means <- compare_all(sims, cfg, modelName, include_init, verbose)
  summ  <- summarise_means(means, cfg)
  save_means(means, cfg, summ, per_rep = per_rep, verbose = verbose)
  
  cat("\n--- accuracy of the mean estimates ---\n")
  print(summ[, c("method", "comp", "mean_err", "rmse_err", "conv_rate")], row.names = FALSE, digits = 4)
  cat("\n--- cluster geometry (true separation", round(min_sep(cfg$mu), 2), ") ---\n")
  print(unique(summ[, c("method", "mean_sep", "overlap_rate", "mean_trace")]), row.names = FALSE, digits = 4)
  
  invisible(list(means = means, summary = summ, sims = sims, cfg = cfg))
}


################################################################################
##  13. DIAGNOSTICS  (did the fit actually find the clusters?)
################################################################################
# sep      distance between the estimated means. Collapsing toward zero while
#          the true separation stays put means the components have merged.
# trace    average variance per component. Far above 1 means the component is
#          covering noise rather than a Gaussian.
# overlap  TRUE when the 95% ellipses intersect. With means 8.5 sigma apart
#          this will never happen in a healthy fit.
################################################################################

diagnose_alpha <- function(alpha, cfg_base = CFG, r = 1, init = cfg_base$init,
                           plot = TRUE, ...) {
  
  cfg <- make_cfg(alpha = alpha, R = cfg_base$R, n = cfg_base$n,
                  base_seed = cfg_base$base_seed, pie = cfg_base$pie,
                  mu = cfg_base$mu, Sigma = cfg_base$Sigma,
                  out_dir = cfg_base$out_dir, init = init,
                  model = cfg_base$model, eig_ratio = cfg_base$eig_ratio, ...)
  
  sim <- simulate_one(r, cfg)
  fb  <- fit_both(sim, cfg)
  
  cat(sprintf("\n============ alpha = %.2f | init = %s | replicate %d ============\n",
              alpha, cfg$init, r))
  cat(sprintf("True contaminated %d of %d | SPL flagged %d | cut %.2f -> %.2f\n",
              length(sim$contam_idx), cfg$n, sum(fb$spl$V == 0L),
              cfg$spl$prop_cut, cfg$spl$target_cut))
  
  cat("\nTrue means:\n"); print(round(cfg$mu, 3))
  cat("Start:\n");        print(round(fb$init$mu, 3))
  cat("EM:\n");           print(round(fb$em$mu, 3))
  cat("SPL:\n");          print(round(fb$spl$mu, 3))
  
  tab <- data.frame(
    what    = c("truth", "start", "EM", "SPL"),
    sep     = c(min_sep(cfg$mu), min_sep(fb$init$mu), min_sep(fb$em$mu), min_sep(fb$spl$mu)),
    trace1  = c(mean(diag(cfg$Sigma[, , 1])), comp_trace(fb$init$Sigma)[1],
                comp_trace(fb$em$Sigma)[1], comp_trace(fb$spl$Sigma)[1]),
    trace2  = c(mean(diag(cfg$Sigma[, , 2])), comp_trace(fb$init$Sigma)[2],
                comp_trace(fb$em$Sigma)[2], comp_trace(fb$spl$Sigma)[2]),
    overlap = c(FALSE, ellipses_overlap(fb$init$mu, fb$init$Sigma),
                ellipses_overlap(fb$em$mu, fb$em$Sigma),
                ellipses_overlap(fb$spl$mu, fb$spl$Sigma)),
    stringsAsFactors = FALSE)
  
  cat("\n"); print(tab, row.names = FALSE, digits = 4)
  
  if (isTRUE(tab$overlap[2]))
    cat("\n-> The START already overlaps: the initialiser is failing at this alpha.\n")
  else if (isTRUE(tab$overlap[4]))
    cat("\n-> Start is clean but SPL drifts into overlap: check the schedule and eig_ratio.\n")
  else if (isTRUE(tab$overlap[3]))
    cat("\n-> EM overlaps, SPL does not. This is the intended finding, not a fault.\n")
  
  if (plot && cfg$d == 2) {
    op <- par(mfrow = c(1, 2)); on.exit(par(op))
    plt_gmm(sim$X, fb$em,  0.95, main = sprintf("EM, alpha = %.2f", alpha))
    plt_gmm(sim$X, fb$spl, 0.95, main = sprintf("SPL, alpha = %.2f", alpha))
  }
  
  invisible(list(cfg = cfg, sim = sim, fits = fb, table = tab))
}

diagnose_sweep <- function(alphas = c(0.00, 0.05, 0.10, 0.20, 0.30, 0.40, 0.50),
                           cfg_base = CFG, r = 1, init = cfg_base$init, ...) {
  out <- do.call(rbind, lapply(alphas, function(a)
    cbind(alpha = a, diagnose_alpha(a, cfg_base, r, init, plot = FALSE, ...)$table)))
  cat("\n================ SUMMARY ACROSS ALPHA ================\n")
  print(out[out$what != "truth", ], row.names = FALSE, digits = 4)
  invisible(out)
}


################################################################################
##  14. ESTIMATE STORE  ->  BIAS AND MSE PER SCENARIO
################################################################################
# Scored parameters: the component MEANS (mu, d coordinates each) and the
# MIXING PROPORTIONS (pie, one scalar each). Both are stored per replicate in
################################################################################

## ---- 14.0 scenario identifier ----------------------------------------------
# Derived from cfg, never typed by hand, so a label cannot disagree with the
# design it came from.
################################################################################

scenario_id <- function(cfg) {
  sprintf("a%02d_n%d_K%d_%s_%s",
          round(100 * cfg$alpha), cfg$n, cfg$K, cfg$init, cfg$model)
}

## ---- 14.1 one replicate -> mu and pie estimates ----------------------------
means_store_one <- function(sim, cfg = CFG, modelName = cfg$model) {
  
  fb <- fit_both(sim, cfg, modelName = modelName)                               # ONE shared start; both fits relabelled onto cfg$mu
  
  one <- function(fit, lab) {
    mu <- matrix(as.numeric(fit$mu), cfg$K, cfg$d)                              # K x d, all NA if the fit failed
    df <- data.frame(scenario = scenario_id(cfg),
                     alpha    = cfg$alpha,
                     n        = cfg$n,
                     init     = cfg$init,
                     model    = modelName,
                     rep      = sim$rep,
                     seed     = sim$seed,
                     method   = lab,
                     comp     = seq_len(cfg$K),
                     stringsAsFactors = FALSE)
    for (j in seq_len(cfg$d)) df[[paste0("mu", j)]]      <- mu[, j]             # the estimate
    for (j in seq_len(cfg$d)) df[[paste0("mu_true", j)]] <- cfg$mu[, j]         # the target, so the file is self-describing
    
    # MIXING PROPORTIONS: relabel_fit() permutes pie with mu, so the estimate
    # on this row belongs to the same component as mu on this row. Storing the
    # target next to it keeps the file self-describing, exactly as for mu.
    pie_hat      <- as.numeric(fit$pie)
    df$pie       <- if (length(pie_hat) == cfg$K) pie_hat else rep(NA_real_, cfg$K)
    df$pie_true  <- as.numeric(cfg$pie)
    
    df$converged <- isTRUE(fit$converged)
    df
  }
  
  rbind(one(fb$em, "EM"), one(fb$spl, "SPL"))                                   # means only, two methods, no init row
}

## ---- 14.2 the store, one scenario ------------------------------------------
collect_means <- function(cfg = CFG, sims = NULL, modelName = cfg$model,
                          verbose = TRUE) {
  
  if (is.null(sims)) sims <- simulate_many(cfg, verbose = verbose)              # or hand in sims you already hold
  
  rows <- vector("list", length(sims))                                          # pre-allocate, never grow in a loop
  for (r in seq_along(sims)) {
    rows[[r]] <- means_store_one(sims[[r]], cfg, modelName)
    if (verbose && r %% 50 == 0)
      cat(sprintf("  EM + SPL means %3d / %d\n", r, length(sims)))
  }
  
  means <- do.call(rbind, rows)
  attr(means, "cfg") <- cfg
  means
}

## ---- 14.3 Bias and MSE per (scenario, method, component) -------------------
# Reads only the stored means. Nothing is refitted here, so this can be rerun
# on a saved means file without touching the simulation.
################################################################################

bias_mse <- function(means, d = NULL) {
  
  if (is.null(d)) d <- sum(grepl("^mu[0-9]+$", names(means)))                   # infer dimension from the columns present
  stopifnot(d >= 1, nrow(means) > 0)
  
  key <- paste(means$scenario, means$method, means$comp, sep = "|")
  
  out <- do.call(rbind, lapply(split(means, key), function(g) {
    
    ok <- !is.na(g[["mu1"]])                                                    # a failed mclust fit is NA on every coordinate
    g  <- g[ok, , drop = FALSE]
    if (!nrow(g)) return(NULL)
    
    row <- data.frame(scenario  = g$scenario[1],
                      alpha     = g$alpha[1],
                      n         = g$n[1],
                      init      = g$init[1],
                      model     = g$model[1],
                      method    = g$method[1],
                      comp      = g$comp[1],
                      reps_used = nrow(g),
                      stringsAsFactors = FALSE)
    
    err2 <- rep(0, nrow(g))                                                     # squared Euclidean error per replicate
    bvec <- numeric(d)
    for (j in seq_len(d)) {
      mh <- g[[paste0("mu", j)]]
      mt <- g[[paste0("mu_true", j)]]
      e  <- mh - mt
      
      bvec[j] <- mean(e)
      row[[paste0("bias_mu", j)]] <- bvec[j]                                    # BIAS
      row[[paste0("var_mu",  j)]] <- if (nrow(g) > 1) var(mh) else NA_real_     # Monte Carlo variance
      row[[paste0("mse_mu",  j)]] <- mean(e^2)                                  # MSE
      err2 <- err2 + e^2
    }
    
    row$bias_norm <- sqrt(sum(bvec^2))                                          # length of the bias vector
    row$mse_total <- mean(err2)                                                 # = sum_j mse_muj
    row$rmse      <- sqrt(row$mse_total)
    
    ## ---- MIXING PROPORTION: same three quantities, one scalar per component
    if (!is.null(g$pie) && !is.null(g$pie_true)) {
      ep <- g$pie - g$pie_true                                                  # signed error per replicate
      row$pie_hat_mean <- mean(ep + g$pie_true)                                 # average estimate, for the table
      row$pie_true     <- g$pie_true[1]
      row$bias_pie     <- mean(ep)                                              # BIAS
      row$abs_bias_pie <- abs(mean(ep))                                         # magnitude, for averaging over components
      row$var_pie      <- if (nrow(g) > 1) var(g$pie) else NA_real_             # Monte Carlo variance
      row$mse_pie      <- mean(ep^2)                                            # MSE
      row$rmse_pie     <- sqrt(row$mse_pie)
      row$se_mse_pie   <- if (nrow(g) > 1) sd(ep^2) / sqrt(nrow(g)) else NA_real_
    }
    row$se_mse    <- if (nrow(g) > 1) sd(err2) / sqrt(nrow(g)) else NA_real_    # MC standard error: is an EM/SPL gap real?
    row$conv_rate <- mean(as.logical(g$converged), na.rm = TRUE)
    row
  }))
  
  out <- out[order(out$alpha, out$method, out$comp), ]
  rownames(out) <- NULL
  out
}

## ---- 14.4 collapsed to (scenario, method) ----------------------------------
# Components averaged: one line per method per contamination level. This is the
################################################################################

bias_mse_overall <- function(bm) {
  
  key <- paste(bm$scenario, bm$method, sep = "|")
  
  out <- do.call(rbind, lapply(split(bm, key), function(g) {
    row <- data.frame(scenario       = g$scenario[1],
                      alpha          = g$alpha[1],
                      n              = g$n[1],
                      init           = g$init[1],
                      model          = g$model[1],
                      method         = g$method[1],
                      K              = nrow(g),
                      reps_used      = min(g$reps_used),
                      mean_bias_norm = mean(g$bias_norm),                              # average bias magnitude across components
                      max_bias_norm  = max(g$bias_norm),                               # the worst component: where EM breaks first
                      mean_mse       = mean(g$mse_total),                              # average MSE across components
                      max_mse        = max(g$mse_total),
                      mean_rmse      = mean(g$rmse),
                      conv_rate      = mean(g$conv_rate),
                      stringsAsFactors = FALSE)
    
    ## ---- MIXING PROPORTION -------------------------------------------------
    # The signed pie errors sum to zero across components by construction
    # (both the estimates and the truth sum to one), so mean(bias_pie) would
    # print ~0 for EVERY method and hide the whole effect. Average the
    # MAGNITUDE here; the signed per-component values stay in the 14.3 table.
    if (!is.null(g$bias_pie)) {
      row$mean_abs_bias_pie <- mean(g$abs_bias_pie)
      row$max_abs_bias_pie  <- max(g$abs_bias_pie)
      row$mean_mse_pie      <- mean(g$mse_pie)
      row$max_mse_pie       <- max(g$mse_pie)
      row$mean_rmse_pie     <- mean(g$rmse_pie)
    }
    row
  }))
  
  out <- out[order(out$alpha, out$method), ]
  rownames(out) <- NULL
  out
}


## ---- 14.5 one scenario: store the means, derive Bias and MSE, save ---------

run_bias_mse <- function(cfg = CFG, sims = NULL, modelName = cfg$model,
                         keep = SAVE, verbose = TRUE) {
  
  cat(sprintf("\n=== BIAS / MSE | scenario %s ===\n", scenario_id(cfg)))
  cat(sprintf("alpha = %.2f | R = %d | n = %d | init = %s | model = %s | cut %.2f -> %.2f\n",
              cfg$alpha, cfg$R, cfg$n, cfg$init, modelName,
              cfg$spl$prop_cut, cfg$spl$target_cut))
  
  means <- collect_means(cfg, sims = sims, modelName = modelName, verbose = verbose)
  bm    <- bias_mse(means)                                                      # per component
  ov    <- bias_mse_overall(bm)                                                 # per method
  
  if (isTRUE(keep$means_store) || isTRUE(keep$per_component) ||
      isTRUE(keep$overall) || isTRUE(keep$workbook)) {
    
    dir.create(cfg$out_dir, showWarnings = FALSE, recursive = TRUE)
    ext <- cfg$xlsx_ext                                                         # same format as the dataset files
    
    if (isTRUE(keep$overall))                                                   # <- the one summary you asked to keep
      write_table_any(ov, cfg$out_dir, paste0(cfg$stem, "_bias_mse_overall"), ext)
    
    if (isTRUE(keep$per_component))
      write_table_any(bm, cfg$out_dir, paste0(cfg$stem, "_bias_mse"), ext)
    
    if (isTRUE(keep$means_store))                                               # always CSV: it is a long raw table
      write_table_any(means, cfg$out_dir, paste0(cfg$stem, "_means_store"), "csv")
    
    if (isTRUE(keep$workbook)) {
      xlsx_path <- file.path(cfg$out_dir, paste0(cfg$stem, "_bias_mse.xlsx"))
      ok <- tryCatch({
        write_xlsx_any(list(means = means, bias_mse = bm, overall = ov), xlsx_path); TRUE
      }, error = function(e) { cat("Excel write skipped:", conditionMessage(e), "\n"); FALSE })
      if (ok) cat("Saved:", xlsx_path, "(sheets: means, bias_mse, overall)\n")
    }
  }
  
  cat("\n--- MEAN: bias and MSE at alpha =", cfg$alpha, "(components averaged) ---\n")
  print(ov[, c("method", "reps_used", "mean_bias_norm", "mean_mse",
               "mean_rmse", "conv_rate")],
        row.names = FALSE, digits = 4)
  
  cat("\n--- MIXING PROPORTION: bias and MSE at alpha =", cfg$alpha,
      "(components averaged, bias in magnitude) ---\n")
  print(ov[, c("method", "reps_used", "mean_abs_bias_pie", "max_abs_bias_pie",
               "mean_mse_pie", "mean_rmse_pie")],
        row.names = FALSE, digits = 4)
  
  cat("\n--- per component ---\n")
  show <- c("method", "comp", "reps_used",
            grep("^bias_mu", names(bm), value = TRUE),
            grep("^mse_mu",  names(bm), value = TRUE),
            "mse_total", "se_mse",
            "pie_true", "bias_pie", "mse_pie", "se_mse_pie")
  show <- show[show %in% names(bm)]
  print(bm[, show], row.names = FALSE, digits = 4)
  
  invisible(list(means = means, bias_mse = bm, overall = ov, cfg = cfg))
}


## ---- 14.6 EVERY scenario in one call ---------------------------------------
# 14.5 scores ONE design point. `scenario_id` keys on alpha / n / K / init /
# model, but a single execution only ever holds one of those, so the split in
# 14.3 and 14.4 has nothing to split. This loops the design, scores each cell
# with the same machinery, and stacks the results into the two tables the
# write-up needs:
#
#   overall  one row per (scenario, method): EM vs SPL, mu and pie
#   by_comp  the same, per component, for the appendix
#
# `grid` is a data frame of make_cfg() arguments, one row per scenario. Any
# column not given falls back to the make_cfg default. Datasets are regenerated
# per scenario (a different alpha is a different population), but within a
# scenario EM and SPL still share one start, so the comparison is unchanged.
################################################################################

run_bias_mse_grid <- function(grid,
                              R       = CFG$R,
                              n       = CFG$n,
                              out_dir = CFG$out_dir,
                              keep    = list(overall = FALSE, per_component = FALSE,
                                             means_store = FALSE, workbook = FALSE),
                              save_stacked = TRUE,
                              verbose = TRUE) {
  
  if (is.numeric(grid)) grid <- data.frame(alpha = grid)                         # a bare vector of alphas is the common case
  stopifnot(is.data.frame(grid), "alpha" %in% names(grid), nrow(grid) >= 1)
  
  if (any(c("init", "model") %in% names(grid)) &&
      (isTRUE(keep$overall) || isTRUE(keep$per_component) ||
       isTRUE(keep$means_store) || isTRUE(keep$workbook)) &&
      any(duplicated(grid[intersect(c("alpha", "n", "R"), names(grid))])))
    warning("grid varies init/model at a repeated alpha-n: per-scenario files ",
            "share a stem and will overwrite. The stacked tables are unaffected.")
  
  overall <- by_comp <- means_all <- NULL
  
  for (i in seq_len(nrow(grid))) {
    
    args <- as.list(grid[i, , drop = FALSE])                                     # this row's overrides
    args <- lapply(args, function(v) if (is.factor(v)) as.character(v) else v)   # older R: stringsAsFactors = TRUE
    args <- args[!vapply(args, function(v) all(is.na(v)), logical(1))]
    if (is.null(args$R))       args$R       <- R
    if (is.null(args$n))       args$n       <- n
    if (is.null(args$out_dir)) args$out_dir <- out_dir
    
    cfg <- do.call(make_cfg, args)                                               # validation runs here, per scenario
    
    cat(sprintf("\n########## SCENARIO %d / %d : %s ##########\n",
                i, nrow(grid), scenario_id(cfg)))
    
    one <- run_bias_mse(cfg, sims = NULL, keep = keep, verbose = verbose)
    
    overall <- rbind(overall, one$overall)
    by_comp <- rbind(by_comp, one$bias_mse)
    if (isTRUE(keep$means_store)) means_all <- rbind(means_all, one$means)
    
    gc()                                                                         # do not hold every scenario's datasets at once
  }
  
  ord <- function(df, by) do.call(order, unname(df[intersect(by, names(df))]))
  overall <- overall[ord(overall, c("alpha", "n", "method")), ]
  by_comp <- by_comp[ord(by_comp, c("alpha", "n", "method", "comp")), ]
  rownames(overall) <- rownames(by_comp) <- NULL
  
  if (save_stacked) {
    dir.create(out_dir, showWarnings = FALSE, recursive = TRUE)
    stem <- sprintf("bias_mse_all_scenarios_R%d", R)
    write_table_any(overall, out_dir, paste0(stem, "_overall"),       "csv")
    write_table_any(by_comp, out_dir, paste0(stem, "_per_component"), "csv")
    ok <- tryCatch({
      write_xlsx_any(list(overall = overall, per_component = by_comp),
                     file.path(out_dir, paste0(stem, ".xlsx"))); TRUE
    }, error = function(e) { cat("Excel write skipped:", conditionMessage(e), "\n"); FALSE })
    if (ok) cat("Saved:", file.path(out_dir, paste0(stem, ".xlsx")),
                "(sheets: overall, per_component)\n")
  }
  
  cat("\n================ MEAN: BIAS AND MSE ACROSS SCENARIOS ================\n")
  print(overall[, c("scenario", "method", "reps_used", "mean_bias_norm",
                    "mean_mse", "mean_rmse", "conv_rate")],
        row.names = FALSE, digits = 4)
  
  cat("\n========= MIXING PROPORTION: BIAS AND MSE ACROSS SCENARIOS =========\n")
  print(overall[, c("scenario", "method", "reps_used", "mean_abs_bias_pie",
                    "mean_mse_pie", "mean_rmse_pie")],
        row.names = FALSE, digits = 4)
  
  invisible(list(overall = overall, per_component = by_comp, means = means_all,
                 grid = grid))
}


## ---- 14.7 EM vs SPL side by side, one line per scenario --------------------
# The stacked table has EM and SPL on separate rows. For the chapter it reads
# better as one row per scenario with the two methods in adjacent columns and
# the ratio that says which one won and by how much.
################################################################################

em_vs_spl_table <- function(overall) {
  
  em  <- overall[overall$method == "EM",  , drop = FALSE]
  spl <- overall[overall$method == "SPL", , drop = FALSE]
  m   <- match(em$scenario, spl$scenario)
  
  data.frame(scenario         = em$scenario,
             alpha            = em$alpha,
             n                = em$n,
             bias_mu_EM       = em$mean_bias_norm,
             bias_mu_SPL      = spl$mean_bias_norm[m],
             mse_mu_EM        = em$mean_mse,
             mse_mu_SPL       = spl$mean_mse[m],
             mse_mu_ratio     = em$mean_mse / spl$mean_mse[m],                   # > 1 means SPL wins
             bias_pie_EM      = em$mean_abs_bias_pie,
             bias_pie_SPL     = spl$mean_abs_bias_pie[m],
             mse_pie_EM       = em$mean_mse_pie,
             mse_pie_SPL      = spl$mean_mse_pie[m],
             mse_pie_ratio    = em$mean_mse_pie / spl$mean_mse_pie[m],
             conv_EM          = em$conv_rate,
             conv_SPL         = spl$conv_rate[m],
             stringsAsFactors = FALSE)
}


################################################################################
##  15. EXECUTION
################################################################################
# Nothing above this line runs anything. Toggle the flags and source the file.
#
# EVERYTHING RUNS AT ONE CONTAMINATION LEVEL: the ALPHA that is set in Section 6.1.
# To study another level,you need change ALPHA (or pass it on the command line) and run
# again -- every output path carries alpha, so nothing is overwritten.
#
################################################################################


RUN <- list(diagnose    = TRUE,                                                 # one replicate: is the fit finding the clusters?
            demo        = TRUE,                                                 # one replicate, printed and plotted
            monte_carlo = TRUE,                                                 # generate + save + one file per replicate
            bias_mse    = TRUE,                                                 # <- ONE scenario: bias and MSE, mu and pie
            scenarios   = FALSE,                                                # <- ALL scenarios in one call (Section 14.6)
            comparison  = FALSE,                                                # the older full-diagnostic EM vs SPL table
            sweep       = FALSE)                                                # OFF: several alphas at once, not this study

# The design for RUN$scenarios. One row per scenario; any make_cfg() argument
# can be a column (alpha, n, init, model, eig_ratio, R, ...). Columns not given
# fall back to the make_cfg defaults. mu / Sigma cannot live in a data frame:
# to vary the true means, call run_bias_mse_grid() once per mu and rbind the
# $overall tables.
SCENARIOS <- expand.grid(alpha = c(0.00, 0.05, 0.10, 0.20, 0.30),
                         n     = c(500),
                         init  = c("tkmeans"),
                         stringsAsFactors = FALSE)

if (RUN$diagnose) {
  diag_out <- diagnose_alpha(CFG$alpha, cfg_base = CFG, r = 1)                  # at CFG$alpha only
}

if (RUN$demo) {
  demo_out <- run_demo(CFG, r = 1, init = CFG$init)
}

if (RUN$monte_carlo) {
  sims <- run_monte_carlo(CFG)                                                  # all R datasets from the TRUE parameters
}

if (RUN$bias_mse) {
  bm_out <- run_bias_mse(CFG,
                         sims = if (exists("sims")) sims else NULL)             # reuse the datasets already generated
  
  means_store        <- bm_out$means                                            # every mean estimate, EM and SPL
  bias_mse_by_comp   <- bm_out$bias_mse                                         # per method / component
  bias_mse_by_method <- bm_out$overall                                          # per method
  
  cat("\nRows per method (expect", CFG$R * CFG$K, "each):\n")
  print(table(means_store$method))
}

if (RUN$scenarios) {                                                            # every design point, stacked
  grid_out <- run_bias_mse_grid(SCENARIOS,
                                R       = CFG$R,
                                n       = CFG$n,
                                out_dir = CFG$out_dir,
                                keep    = list(overall       = TRUE,            # per-scenario files as well
                                               per_component = TRUE,
                                               means_store   = FALSE,
                                               workbook      = FALSE))
  
  bias_mse_all_scenarios <- grid_out$overall                                    # EM and SPL on separate rows
  bias_mse_all_by_comp   <- grid_out$per_component
  
  side_by_side <- em_vs_spl_table(bias_mse_all_scenarios)                       # one row per scenario
  cat("\n=============== EM vs SPL, ONE ROW PER SCENARIO ===============\n")
  print(side_by_side, row.names = FALSE, digits = 4)
  
  write_table_any(side_by_side, CFG$out_dir,
                  sprintf("bias_mse_em_vs_spl_R%d", CFG$R), "csv")
}

if (RUN$comparison) {
  if (!exists("sims")) sims <- simulate_many(CFG)
  res <- run_em_vs_spl(CFG, sims = sims, per_rep = FALSE)
  
  cat("\nRows per method (expect", CFG$R * CFG$K, "each):\n")
  print(table(res$means$method))
  cat("\nInitialisation used by each method:\n")
  print(table(res$means$method, res$means$init, useNA = "ifany"))
}

if (RUN$sweep) {                                                                # only if you deliberately want several levels
  sweep_out <- run_alpha_sweep(alphas = c(0.00, 0.05, 0.10, 0.20, 0.30),
                               fit = TRUE, init = CFG$init,
                               R = CFG$R, n = CFG$n, out_dir = CFG$out_dir,
                               xlsx_mode = CFG$xlsx_mode, xlsx_ext = CFG$xlsx_ext,
                               eig_ratio = CFG$eig_ratio)
}

cat("\nDone.\n")



################################################################################
##    16. Real data: Old  Faithful, EM vs SPL, K selected by BIC               # 
################################################################################
# For this we do not have true parameters exist so we have nothing to score 
# agaist
# choice is by BIC and the two methods are compared on the fitted solution.
#   BIC = -2 * loglik + npar * log(n)      where lower is better
################################################################################

## 16.1 parameter count and criteria
npar_VVV <- function(K, d) (K - 1) + K * d + K * d * (d + 1) / 2  
bic_from <- function(loglik, npar, n) -2 * loglik + npar * log(n)  

## 16.2 EM for a given K

# K = 1 is done in closed form: mclust names the single-component multivariate
# covariance, so there is nothing to iterate.
fit_em_K <- function(X, init, K) {
  X <- as.matrix(X); n <- nrow(X); d <- ncol(X)
  if (K == 1L) {
    mu    <- matrix(colMeans(X), 1, d)
    Sigma <- array(cov(X) * (n - 1) / n, c(d, d, 1))                            # MLE, not the unbiased estimate
    ll    <- sum(log_dmvn(X, mu[1, ], Sigma[, , 1]))
    return(list(pie = 1, mu = mu, Sigma = Sigma, loglik = ll,
                converged = TRUE, method = "EM"))
  }
  fit_em(X, init, modelName = "VVV")
}


##   16.3 one K: shared start, both methods 
fit_real_one <- function(X, K, trim = 0.05, seed = 2026L,
                         eig_ratio = 50, cut_margin = 0.20,
                         cut_decay = 0.05, max_outer = 300,
                         max_inner = 100, tol = 1e-6) {
  
  X <- as.matrix(X); n <- nrow(X); d <- ncol(X)
  
  init <- init_tkmeans(X, K, seed = seed, trim = trim, nstart = 50)             # ONE start, shared by both fitters
  
  em  <- fit_em_K(X, init, K)
  
  spl <- gmm_em_spl(X, init$pie, init$mu, init$Sigma,
                    prop_cut   = min(trim + cut_margin, 0.5),
                    target_cut = trim,
                    cut_decay  = cut_decay,
                    eig_ratio  = eig_ratio,
                    max_outer  = max_outer,
                    max_inner  = max_inner,
                    tol        = tol)
  npar   <- npar_VVV(K, d)
  n_keep <- sum(spl$V == 1L)
  
  list(K = K, trim = trim, npar = npar,
       em = em, spl = spl, init = init,
       bic_em  = if (is.finite(em$loglik)) bic_from(em$loglik,  npar, n) else NA_real_,
       bic_spl = bic_from(spl$loglik, npar, n_keep),                            # TRIMMED BIC, see header note
       n_keep = n_keep, n_flagged = n - n_keep)
}

## 16.4 Sweep over K
fit_real_sweep <- function(X, Ks = 1:6, trim = 0.05, seed = 2026L, ...) {
  
  fits <- lapply(Ks, function(k) {
    cat(sprintf("  fitting K = %d ...\n", k))
    fit_real_one(X, k, trim = trim, seed = seed, ...)
  })
  names(fits) <- paste0("K", Ks)
  
  tab <- do.call(rbind, lapply(fits, function(f) data.frame(
    K          = f$K,
    npar       = f$npar,
    loglik_EM  = f$em$loglik,
    BIC_EM     = f$bic_em,
    loglik_SPL = f$spl$loglik,
    BIC_SPL    = f$bic_spl,
    n_flagged  = f$n_flagged,
    conv_EM    = isTRUE(f$em$converged),
    conv_SPL   = isTRUE(f$spl$converged),
    stringsAsFactors = FALSE)))
  rownames(tab) <- NULL

  list(fits = fits, table = tab,
       K_em  = tab$K[which.min(tab$BIC_EM)],
       K_spl = tab$K[which.min(tab$BIC_SPL)])
}

##  16.5 report the selected model
# Estimates are reported on the ORIGINAL scale. If X was standardised as
# (X - centre) / scl, then  mu_orig = mu * scl + centre  and
# Sigma_orig = diag(scl) %*% Sigma %*% diag(scl).

unscale_mu    <- function(mu, centre, scl)  sweep(sweep(mu, 2, scl, "*"), 2, centre, "+")
unscale_Sigma <- function(Sigma, scl) {
  D <- diag(scl, length(scl))
  for (k in seq_len(dim(Sigma)[3])) Sigma[, , k] <- D %*% Sigma[, , k] %*% D
  Sigma
}

report_real_fit <- function(f, X_raw, centre, scl, varnames = colnames(X_raw)) {
  
  cat(sprintf("\n================ SELECTED MODEL: K = %d, trim = %.2f ================\n",
              f$K, f$trim))
  
  for (m in c("em", "spl")) {
    fit <- f[[m]]
    lab <- toupper(m)
    cat(sprintf("\n---- %s ----\n", lab))
    cat("Mixing proportions:\n"); print(round(fit$pie, 4))
    cat("Component means (original scale):\n")
    mu <- unscale_mu(matrix(fit$mu, f$K, ncol(X_raw)), centre, scl)
    colnames(mu) <- varnames; rownames(mu) <- paste("comp", seq_len(f$K))
    print(round(mu, 3))
    cat("Component covariances (original scale):\n")
    Sg <- unscale_Sigma(array(fit$Sigma, c(ncol(X_raw), ncol(X_raw), f$K)), scl)
    for (k in seq_len(f$K)) {
      cat(sprintf(" component %d:\n", k))
      S <- Sg[, , k]; dimnames(S) <- list(varnames, varnames)
      print(round(S, 3))
    }
    cat(sprintf("log-likelihood: %.3f  (%s)\n", fit$loglik,
                if (m == "em") "full, all n points" else "trimmed, kept points only"))
  }
  
  
  ## outliers that we found by SPL 
  out_idx <- which(f$spl$V == 0L)
  cat(sprintf("\n---- OUTLIERS IDENTIFIED BY SPL ----\n"))
  cat(sprintf("Flagged: %d of %d observations (%.1f%%) | lambda = %.4f\n",
              length(out_idx), nrow(X_raw),
              100 * length(out_idx) / nrow(X_raw), f$spl$lambda))
  if (length(out_idx)) {
    obs <- cbind(obs = out_idx, as.data.frame(X_raw[out_idx, , drop = FALSE]),
                 loglik = round(f$spl$ell[out_idx], 3))
    print(obs, row.names = FALSE)
  }

  ## check if the two methods agree on the partition 
  em_lab  <- max.col(f$em$responsibilities %||% estep_log(
    scale(X_raw, centre, scl), f$em$pie, f$em$mu, f$em$Sigma)$r, ties.method = "first")
  cat("\n---- EM label vs SPL label (0 = flagged by SPL) ----\n")
  print(table(EM = em_lab, SPL = f$spl$labels))
  
  invisible(list(outliers = out_idx, em_labels = em_lab, spl_labels = f$spl$labels))
}


`%||%` <- function(a, b) if (is.null(a)) b else a

## 16.6 sensitivity to the trimming level
# alpha is unknown on real data. target_cut is a choice, so report the choice
# and show what the answer does when it changes.
trim_sensitivity <- function(X, K, trims = c(0.00, 0.02, 0.05, 0.10), seed = 2026L, ...) {
  do.call(rbind, lapply(trims, function(t) {
    f <- fit_real_one(X, K, trim = t, seed = seed, ...)
    data.frame(trim = t, n_flagged = f$n_flagged,
               loglik_SPL = f$spl$loglik, BIC_SPL = f$bic_spl,
               min_sep = min_sep(f$spl$mu),
               pie = paste(round(sort(f$spl$pie, decreasing = TRUE), 3), collapse = " / "),
               stringsAsFactors = FALSE)
  }))
}


##  16.7 The run it 
RUN_REAL <- TRUE

if (RUN_REAL) {
  
  data(faithful)
  X_raw <- as.matrix(faithful) 
  
  centre <- colMeans(X_raw)
  scl    <- apply(X_raw, 2, sd)
  X      <- scale(X_raw, center = centre, scale = scl)
  
  cat("\n### Old Faithful: n =", nrow(X), ", d =", ncol(X), "###\n")
  
  sweep_out <- fit_real_sweep(X, Ks = 1:6, trim = 0.05, seed = 2026L,
                              eig_ratio = 50)
  
  cat("\n---- BIC over K (lower is better) ----\n")
  print(sweep_out$table, row.names = FALSE, digits = 6)
  cat(sprintf("\nEM  selects K = %d\nSPL selects K = %d\n",
              sweep_out$K_em, sweep_out$K_spl))
  
  best <- sweep_out$fits[[paste0("K", sweep_out$K_spl)]]
  rep_out <- report_real_fit(best, X_raw, centre, scl)
  
  cat("\n---- sensitivity of the SPL fit to the trimming level ----\n")
  print(trim_sensitivity(X, sweep_out$K_spl, eig_ratio = 50),
        row.names = FALSE, digits = 4)
  
  ## plots on the original scale
  op <- par(mfrow = c(1, 2)); on.exit(par(op), add = TRUE)
  em_as_fit <- list(mu    = unscale_mu(best$em$mu, centre, scl),
                    Sigma = unscale_Sigma(best$em$Sigma, scl),
                    pie   = best$em$pie,
                    labels = rep_out$em_labels, V = rep(1L, nrow(X_raw)))
  spl_as_fit <- list(mu    = unscale_mu(best$spl$mu, centre, scl),
                     Sigma = unscale_Sigma(best$spl$Sigma, scl),
                     pie   = best$spl$pie,
                     labels = best$spl$labels, V = best$spl$V)
  plt_gmm(X_raw, em_as_fit,  0.95, main = sprintf("Old Faithful: EM, K = %d",  best$K))
  plt_gmm(X_raw, spl_as_fit, 0.95, main = sprintf("Old Faithful: SPL, K = %d", best$K))
  
  
  ## BIC curve
  with(sweep_out$table, {
    matplot(K, cbind(BIC_EM, BIC_SPL), type = "b", pch = c(16, 15),
            col = c("firebrick3", "navy"), lty = 1,
            xlab = "K", ylab = "BIC (lower is better)",
            main = "BIC over K: EM (full lik.) vs SPL (trimmed lik.)")
    legend("topright", c("EM", "SPL (trimmed)"), col = c("firebrick3", "navy"),
           pch = c(16, 15), lty = 1, bty = "n")
  })
}

